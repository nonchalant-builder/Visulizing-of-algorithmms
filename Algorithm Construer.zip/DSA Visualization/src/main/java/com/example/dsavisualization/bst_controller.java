package com.example.dsavisualization;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Bounds;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

class Node{
    int val;
    Node left;
    Node right;
    Node parent;
    int level;
    StackPane stack;
    Line edge;
    Node(int val){
        this.val=val;
        left=null;
        right=null;
        parent=null;

        stack=new StackPane();
        Circle circle = new Circle(20);
       // circle.setFill(Color.LIGHTBLUE);   // ⭐ fix
        circle.setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.web("#e6f4ff")),
                new Stop(1, Color.web("#bcdcff"))
        ));
        circle.setStroke(Color.web("#6b8fbf"));
      //  circle.setStroke(Color.BLACK);     // border
        circle.setStrokeWidth(3);
        Text text=new Text();
        text.setFill(Color.BLACK);
        text.setStyle("-fx-font-size: 14px;-fx-font-weight: bold;");
        text.setText(String.valueOf(val));
        stack.getChildren().addAll(circle,text);
    }
}

class Information_bst{
    StackPane stack;
    Line edge;
   // boolean found=false;
    boolean color_edge=true;
    //  boolean color_circle=false;
    boolean just_found=false;
    boolean visited=false;
    boolean leave=false;

    boolean delete_leaf=false;
    boolean delete_has_left_subtree=false;
    boolean delete_has_right_subtree=false;
    boolean delete_has_both_subtrees=false;

    ArrayList<Node> movable_node;
    double dx;
    double dy;
    Line deleting_edge;
    Node p1,p2;
    boolean exchange_val=false;
    String exchange_data;
    boolean target=false;
}

public class bst_controller {
    private double radius=20;
    private double width=1550;
    private StackPane []stacks=new StackPane[100];
    Information_bst []information=new Information_bst[1000];
    private Circle []circles=new Circle[100];
    private Line []lines=new Line[100];
    ArrayList<Animation> activeAnimations = new ArrayList<>();
    // private StackPane []information=new StackPane[100];
    boolean delete_btn_on=false;
    private Circle currCircle;
    private int circles_count;
    private int lines_count;
    private int info_count;
    private int stacks_count;
    private Timeline timeline;
    private int step_idx;
    Node root=null;
    @FXML
    private AnchorPane bst_container;
    @FXML
    private TextField insert_text;
    @FXML
    private TextField delete_text;
    @FXML
    private TextField search_text;
    @FXML
    private TextField successor_text;
    @FXML
    private TextField predecessor_text;
    @FXML
    private void insert_btn_clicked(){
        if (timeline!=null){
            return;
        }
        insert_code();
        String txt=insert_text.getText().trim();
        insert_text.clear();
        if (txt.isEmpty() || !txt.matches("^-?[0-9]+$")) {
            return;
        }
        try {
            insert(Integer.parseInt(txt));
        }catch (NumberFormatException e){
            System.out.println("error in input.");
        }
    }
    @FXML
    private void delete_btn_clicked(){
        if (timeline!=null){
            return;
        }
        delete_code();

        delete_btn_on=true;
        String txt=delete_text.getText().trim();
        delete_text.clear();
        if (txt.isEmpty() || !txt.matches("^-?[0-9]+$")) {
            return;
        }
        // info_count=0;
        info_count = 0;
        step_idx = 0;
        try{
            root=delete(root,Integer.parseInt(txt));
            start_delete_timeline();
        }catch (NumberFormatException e){
            System.out.println("error in input.");
        }
    }
    @FXML
    private void search_btn_clicked(){
        if (timeline!=null){
            return;
        }
        search_code();
        String txt=search_text.getText().trim();
        search_text.clear();
        if (txt.isEmpty() || !txt.matches("^-?[0-9]+$")) {
            return;
        }
        try{
            search(Integer.parseInt(txt));
        }catch (NumberFormatException e){
            System.out.println("error in input.");
        }
    }
    private void insert(int val){
        if(root==null){
            root=new Node(val);
            root.level=0;
          //  root.stack.setLayoutX(1550/2);
            root.stack.setLayoutX(1550/2);
            root.stack.setLayoutY(20);
            bst_container.getChildren().add(root.stack);

            stacks_count=0;
            circles_count=0;
            lines_count=0;
            stacks[stacks_count++]=root.stack;
            circles[circles_count++]=(Circle) root.stack.getChildren().get(0);
            //indicates the current node
            currCircle=new Circle(24);
            currCircle.setFill(Color.TRANSPARENT);
           // currCircle.setStroke(Color.RED);
            currCircle.setStroke(new LinearGradient(
                    0, 0, 0, 1,
                    true,                 // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.web("#ff7b7b")),
                    new Stop(1, Color.web("#d70000"))
            ));
            currCircle.setStrokeWidth(3);
            currCircle.setEffect(new DropShadow(8, Color.rgb(255,0,0,0.4)));
            currCircle.setVisible(false);
           // bst_container.getChildren().add(currCircle);
            currCircle.toFront();

            return;
        }
        Node newNode=new Node(val);
        Node temp=root;
        Node p=temp;
        while(temp!=null){
            p=temp;
            if(val<temp.val){
                temp=temp.left;
            }
            else if(val>temp.val){
                temp=temp.right;
            }
            else{
                return;
            }
        }
        double x1,y1;
        double a=radius/1.414;
        if(val<p.val){
            newNode.stack.setLayoutX(p.stack.getLayoutX()-((double) width/(4*(p.level+1))));
            newNode.stack.setLayoutY(p.stack.getLayoutY()+80);

            //boundary checking
            int newNode_x=(int)newNode.stack.getLayoutX();
            int newNode_y=(int)newNode.stack.getLayoutY();
            if(newNode_x<10 || newNode_x>=1500 || newNode_y>=500){
                return;
            }
            for(int i=0;i<stacks_count;i++){
                int stack1_x=(int)newNode.stack.getLayoutX();
                int stack1_y=(int)newNode.stack.getLayoutY();
                int stack2_x=(int)stacks[i].getLayoutX();
                int stack2_y=(int)stacks[i].getLayoutY();
                if(checkAABBCollision(stack1_x,stack1_y,stack2_x,stack2_y)){
                    return;
                }
            }
            //boundary check end
            //node saving in bst
            newNode.parent=p;
            newNode.level=p.level+1;
            p.left=newNode;

            x1=(double) p.stack.getLayoutX()+radius-a;
            y1=(double) p.stack.getLayoutY()+radius+a;
        }
        else{
            newNode.stack.setLayoutX(p.stack.getLayoutX()+((double) width/(4*(p.level+1))));
            newNode.stack.setLayoutY(p.stack.getLayoutY()+80);

            //boundary checking
            int newNode_x=(int)newNode.stack.getLayoutX();
            int newNode_y=(int)newNode.stack.getLayoutY();
            if(newNode_x<10 || newNode_x>=1450 || newNode_y>=500){
                return;
            }
            for(int i=0;i<stacks_count;i++){
                int stack1_x=(int)newNode.stack.getLayoutX();
                int stack1_y=(int)newNode.stack.getLayoutY();
                int stack2_x=(int)stacks[i].getLayoutX();
                int stack2_y=(int)stacks[i].getLayoutY();
                if(checkAABBCollision(stack1_x,stack1_y,stack2_x,stack2_y)){
                    return;
                }
            }
            //saving node in bst
            newNode.parent=p;
            newNode.level=p.level+1;
            p.right=newNode;

            x1=(int)p.stack.getLayoutX()+radius+a+1.5;
            y1=(int)p.stack.getLayoutY()+radius+a+1.5;
        }
        double x2=(double) newNode.stack.getLayoutX()+radius;
        double y2=(double) newNode.stack.getLayoutY();
        Line line=new Line(x1,y1,x2,y2);
        line.setStroke((Color.web("#6b8fbf")));
        //need to alert here
        newNode.edge=line;//child will keep the edge of parent to child
        line.setStrokeWidth(2);

        circles[circles_count++]=(Circle) newNode.stack.getChildren().get(0);
        lines[lines_count++]=line;
        stacks[stacks_count++]=newNode.stack;
        bst_container.getChildren().add(line);
        bst_container.getChildren().add(newNode.stack);

    }
    @FXML
    private void random_btn_clicked(){
        if (timeline!=null){
            return;
        }
        if(root!=null){
            bst_container.getChildren().clear();
            root=null;
            stacks_count=0;
        }
        Random random=new Random();
        for(int i=0;i<30;i++){
            int num=random.nextInt(101);
            insert(num);
        }
       // print(root);
    }
   /* private void print(Node temp){
        if(temp==null){
            return;
        }
        print(temp.left);
        System.out.println(temp.val);
        print(temp.right);
    }*/

    private boolean checkAABBCollision(int x1,int y1,int x2, int y2)
    {
        int w=(int)radius*2;
        boolean x_overlap=(x1<x2 + w) && (x1+w > x2);
        boolean y_overlap=(y1<y2 + w) && (y1+w > y2);
        return (x_overlap && y_overlap);
    }
    private void search(int val){
        Node temp=root;
        info_count=0;
        while(temp!=null && temp.val!=val){
            information[info_count]=new Information_bst();
            information[info_count].stack=temp.stack;
            information[info_count].edge=temp.edge;
            information[info_count++].just_found=true;
            if(val<temp.val){
                temp=temp.left;
            }
            else{
                temp=temp.right;
            }
        }
        if(temp!=null && temp.val==val){
            information[info_count]=new Information_bst();
            information[info_count].stack=temp.stack;
            information[info_count].edge=temp.edge;
            information[info_count++].visited=true;
        }
        start_timeline();
    }
    private void start_timeline(){
        if(timeline!=null){
            return;
        }
        bst_container.getChildren().add(currCircle);
        timeline=new Timeline(new KeyFrame(Duration.millis(600), e->step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        step_idx=0;
        timeline.play();
    }
    private void step(){
        if(step_idx<info_count && step_idx>=0){
            /*highlight_border(information[step_idx].stack);
            if(information[step_idx].color_edge) {
                highlight_edge(information[step_idx].edge);
            }
            if(information[step_idx].found){
                color_circle(information[step_idx].stack);
            }
            step_idx++;*/

            StackPane stack = information[step_idx].stack;
            currCircle.setCenterX(stack.getLayoutX() + stack.getWidth() / 2);
            currCircle.setCenterY(stack.getLayoutY() + stack.getHeight() / 2);
            currCircle.setVisible(true);

            /*if(information[step_idx].just_found){
                if(information[step_idx].color_edge && information[step_idx].edge!=null){
                    highlight_edge(information[step_idx].edge);
                }
                highlight_border(information[step_idx].stack);
            }
            if(information[step_idx].visited){
                color_circle(information[step_idx].stack);
            }
            step_idx++;*/

            if(information[step_idx].just_found){
                highlight_edge(information[step_idx].edge);
                highlight_border(information[step_idx].stack);
            }
            if(information[step_idx].visited){
                color_circle(information[step_idx].stack);
            }
            step_idx++;
        }
    }
    private void highlight_border(StackPane stack){
        Circle circle=(Circle)stack.getChildren().get(0);
        StrokeTransition st=new StrokeTransition(Duration.millis(300),circle);
        st.setFromValue((Color)circle.getStroke());
        st.setToValue(Color.web("#ffe58a"));
        activeAnimations.add(st);
        st.play();
    }
    private void highlight_edge(Line edge){
        if(edge==null){
            return;
        }
        StrokeTransition st=new StrokeTransition(Duration.millis(400),edge);
        st.setFromValue((Color) edge.getStroke());
        st.setToValue(Color.web("#ffe58a"));
        activeAnimations.add(st);
        st.play();
    }
   /* private void color_circle(StackPane stack){
        Circle circle=(Circle)stack.getChildren().get(0);
        FillTransition ft=new FillTransition(Duration.millis(250), circle);
        ft.setFromValue((Color) circle.getFill());
        ft.setToValue(Color.LIMEGREEN);
        activeAnimations.add(ft);
        ft.play();
    }*/
    private void color_circle(StackPane stack){
        Circle circle = (Circle) stack.getChildren().get(0);
        FillTransition ft = new FillTransition(Duration.millis(250), circle);
        // ✅ DO NOT read circle.getFill()
        // give a base color manually
        ft.setFromValue(Color.web("#bcdcff"));  // soft blue
        ft.setToValue(Color.LIMEGREEN);
        activeAnimations.add(ft);
        ft.play();

    }

    @FXML
    private void minimum_btn_clicked(){
        if (timeline!=null){
            return;
        }
        if(root==null){
            return;
        }
        minimum_code();
        info_count=0;
        Node temp=root;
        while(temp!=null){
            information[info_count]=new Information_bst();
            information[info_count].stack=temp.stack;
            information[info_count].edge=temp.edge;
            information[info_count++].just_found=true;
            temp=temp.left;
        }
        if(root!=null){
            information[info_count-1].visited=true;
        }
        information[0].color_edge=false;
        start_timeline();
    }
    @FXML
    private void maximum_btn_clicked(){
        if (timeline!=null){
            return;
        }
        if(root==null){
            return;
        }
        maximum_code();
        info_count=0;
        Node temp=root;
        while(temp!=null){
            information[info_count]=new Information_bst();
            information[info_count].stack=temp.stack;
            information[info_count].edge=temp.edge;
            information[info_count++].just_found=true;
            temp=temp.right;
        }
        if(root!=null){
            information[info_count-1].visited=true;
        }
        information[0].color_edge=false;
        start_timeline();
    }

    @FXML
    private void successor_btn_clicked(){
        if (timeline!=null){
            return;
        }
        successor_code();
        String txt=successor_text.getText().trim();
        successor_text.clear();
        if (txt.isEmpty() || !txt.matches("^-?[0-9]+$")) {
            return;
        }
        if(root==null){
            return;
        }
        try {
            successor(Integer.parseInt(txt));
        }catch (NumberFormatException e){
            System.out.println("error in input.");
        }
    }
    private void successor(int val){
        Node temp=root;
        while(temp!=null && temp.val!=val){
            if(val<temp.val){
                temp=temp.left;
            }
            else if(val>temp.val){
                temp=temp.right;
            }
        }
        if(temp==null || temp.val!=val){
            return;
        }
        //main successor code
        if(temp.right!=null){
            info_count=0;
            Node p=temp;
            information[info_count]=new Information_bst();
            information[info_count].stack=p.stack;
            information[info_count].edge=p.edge;
            information[info_count++].just_found=true;
            p=p.right;
            while(p!=null){
                information[info_count]=new Information_bst();
                information[info_count].stack=p.stack;
                information[info_count].edge=p.edge;
                information[info_count++].just_found=true;
                p=p.left;
            }
            if(info_count>0){
                information[info_count-1].visited=true;
            }
            information[0].color_edge=false;
            start_timeline();
            return;
        }
        //if node don't have any left subtree then:
        info_count=0;
        Node x=temp;
        Node y=temp.parent;
        information[info_count]=new Information_bst();
        information[info_count].stack=x.stack;
        information[info_count].edge=x.edge;
        information[info_count++].just_found=true;
        while(y!=null && x==y.right){
            x=y;
            y=y.parent;
            information[info_count]=new Information_bst();
            information[info_count].stack=x.stack;
            information[info_count].edge=x.edge;
            information[info_count++].just_found=true;
        }
        if(info_count>0 && y!=null){
            x=x.parent;
            information[info_count]=new Information_bst();
            information[info_count].stack=x.stack;
            information[info_count].edge=x.edge;
            information[info_count].color_edge=false;
            information[info_count++].visited=true;
        }
        start_timeline();
    }

    @FXML
    private void predecessor_btn_clicked(){
        if (timeline!=null){
            return;
        }
        predecessor_code();
        String txt=predecessor_text.getText().trim();
        predecessor_text.clear();
        if (txt.isEmpty() || !txt.matches("^-?[0-9]+$")) {
            return;
        }
        if(root==null){
            return;
        }
        try {
            predecessor(Integer.parseInt(txt));
        }catch (NumberFormatException e){
            System.out.println("error in input.");
        }
    }
    private void predecessor(int val){
        Node temp=root;
        while(temp!=null && temp.val!=val){
            if(val<temp.val){
                temp=temp.left;
            }
            else if(val>temp.val){
                temp=temp.right;
            }
        }
        if(temp==null || temp.val!=val){
            return;
        }
        //main successor code
        if(temp.left!=null){
            info_count=0;
            Node p=temp;
            information[info_count]=new Information_bst();
            information[info_count].stack=p.stack;
            information[info_count].edge=p.edge;
            information[info_count++].just_found=true;
            p=p.left;
            while(p!=null){
                information[info_count]=new Information_bst();
                information[info_count].stack=p.stack;
                information[info_count].edge=p.edge;
                information[info_count++].just_found=true;
                p=p.right;
            }
            if(info_count>0){
                information[info_count-1].visited=true;
            }
            information[0].color_edge=false;
            start_timeline();
            return;
        }
        //if node don't have any left subtree then:
        info_count=0;
        Node x=temp;
        Node y=temp.parent;
        information[info_count]=new Information_bst();
        information[info_count].stack=x.stack;
        information[info_count].edge=x.edge;
        information[info_count++].just_found=true;
        while(y!=null && x==y.left){
            x=y;
            y=y.parent;
            information[info_count]=new Information_bst();
            information[info_count].stack=x.stack;
            information[info_count].edge=x.edge;
            information[info_count++].just_found=true;
        }
        if(info_count>0 && y!=null){
            x=x.parent;
            information[info_count]=new Information_bst();
            information[info_count].stack=x.stack;
            information[info_count].edge=x.edge;
            information[info_count].color_edge=false;
            information[info_count++].visited=true;
        }
        start_timeline();
    }
    @FXML
    private void in_order_btn_clicked(){
        if(timeline!=null){
            return;
        }
        if(root==null){
            return;
        }
        inorder_code();
        info_count=0;
        in_order(root);
       /*System.out.println("------ BST INFORMATION STATUS ------");
        for (int i = 0; i < info_count; i++) {
            Information_bst info = information[i];
            Text text = (Text) info.stack.getChildren().get(1);
            System.out.printf(
                    "Index: %d | Value: %s | found: %b | color_edge: %b%n",
                    i,
                    text.getText(),
                    info.visited,
                    info.color_edge
            );
        }
        System.out.println("------------------------------------");*/
        information[0].color_edge=false;
        start_timeline();

    }
    private void in_order(Node temp){
        if(temp==null){
            return;
        }
        information[info_count]=new Information_bst();
        information[info_count].stack=temp.stack;
        information[info_count].edge=temp.edge;
        information[info_count++].just_found=true;
        in_order(temp.left);
        information[info_count]=new Information_bst();
        information[info_count].stack=temp.stack;
        information[info_count].edge=temp.edge;
        information[info_count].color_edge=false;
        information[info_count++].visited=true;
        in_order(temp.right);
        information[info_count]=new Information_bst();
        information[info_count].stack=temp.stack;
        information[info_count].edge=temp.edge;
        information[info_count++].leave=true;
    }
    @FXML
    private void pre_order_btn_clicked(){
        if(timeline!=null){
            return;
        }
        if(root==null){
            return;
        }
        preorder_code();
        info_count=0;
        pre_order(root);
        information[0].color_edge=false;
        start_timeline();

    }
    private void pre_order(Node temp){
        if(temp==null){
            return;
        }

        information[info_count] = new Information_bst();
        information[info_count].stack = temp.stack;
        information[info_count].edge  = temp.edge;
        information[info_count++].just_found = true;

        information[info_count] = new Information_bst();
        information[info_count].stack = temp.stack;
        information[info_count].edge  = temp.edge;
        information[info_count].color_edge = false;
        information[info_count++].visited = true;

        pre_order(temp.left);

        pre_order(temp.right);

        information[info_count] = new Information_bst();
        information[info_count].stack = temp.stack;
        information[info_count].edge  = temp.edge;
        information[info_count++].leave = true;
    }
    @FXML
    private void post_order_btn_clicked(){
        if(timeline!=null){
            return;
        }
        if(root==null){
            return;
        }
        postorder_code();
        info_count=0;
        post_order(root);
        information[0].color_edge=false;
        start_timeline();

    }
    private void post_order(Node temp){
        if(temp==null){
            return;
        }
        information[info_count] = new Information_bst();
        information[info_count].stack = temp.stack;
        information[info_count].edge  = temp.edge;
        information[info_count++].just_found = true;

        post_order(temp.left);

        post_order(temp.right);

        information[info_count] = new Information_bst();
        information[info_count].stack = temp.stack;
        information[info_count].edge  = temp.edge;
        information[info_count].color_edge = false;
        information[info_count++].visited = true;

        information[info_count] = new Information_bst();
        information[info_count].stack = temp.stack;
        information[info_count].edge  = temp.edge;
        information[info_count++].leave = true;
    }
    @FXML
    private void stop_btn_clicked(){
        if (timeline!=null) {
            timeline.stop();
            timeline = null;
        }
        if(root==null){
            return;
        }
        for(Animation a : activeAnimations){
            a.stop();
        }
        activeAnimations.clear();
        if(currCircle!=null) {
            bst_container.getChildren().remove(currCircle);
        }
        reset_secondarily();//just color resetting
    }
    private void reset_secondarily(){
        if(root==null){
            return;
        }
        for(int i=0;i<circles_count;i++){
            circles[i].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.web("#e6f4ff")),
                    new Stop(1, Color.web("#bcdcff"))
            ));
            circles[i].setStroke(Color.web("#6b8fbf"));
        }
        for(int i=0;i<lines_count;i++){
            lines[i].setStroke(Color.web("#6b8fbf"));
        }
        currCircle.setVisible(false);
        delete_btn_on=false;
    }
    @FXML
    private void reset_btn_clicked(){
        if (timeline!=null) {
            timeline.stop();
            timeline = null;
        }
        for(Animation a : activeAnimations) {
            a.stop();
        }
        activeAnimations.clear();
        bst_container.getChildren().clear();
        root=null;
        step_idx=0;
        stacks_count=0;
        circles_count=0;
        lines_count=0;
        delete_btn_on=false;
        insert_code();
    }
    @FXML
    private void pause_btn_clicked(){
        if(root==null){
            return;
        }
        if(timeline!=null){
            timeline.pause();
        }
    }
    @FXML
    private void resume_btn_clicked(){
        if(root==null){
            return;
        }
        if(timeline!=null && timeline.getStatus()== Animation.Status.PAUSED){
            timeline.play();
        }
    }
    @FXML
    private void speed_up_btn_clicked(){
        if(root==null){
            return;
        }
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate<3){
                timeline.setRate(curr_rate+.5);
            }
        }
    }
    @FXML
    private void speed_down_btn_clicked(){
        if(root==null){
            return;
        }
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate>.5){
                timeline.setRate(curr_rate-.5);
            }
        }
    }
    @FXML
    private void next_step_btn_clicked(){
        if(root==null){
            return;
        }
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                if(delete_btn_on) {
                    delete_step();
                }
                else{
                    step();
                }
            }
        }
    }
    @FXML
    private void previous_step_btn_clicked(){
        if(root==null){
            return;
        }
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                if(delete_btn_on) {
                    delete_step_prev();
                }
                else{
                    step_prev();
                }
            }
        }
    }
    private void step_prev(){
        if(step_idx>0 && step_idx<=info_count){
            step_idx--;

            StackPane stack;
            if(step_idx==0){
                 stack = information[step_idx].stack;
            }
            else {
                 stack = information[step_idx - 1].stack;
            }
            currCircle.setCenterX(stack.getLayoutX() + stack.getWidth() / 2);
            currCircle.setCenterY(stack.getLayoutY() + stack.getHeight() / 2);
            currCircle.setVisible(true);

            if(information[step_idx].just_found){
                reverse_highlight_edge(information[step_idx].edge);
                reverse_highlight_border(information[step_idx].stack);
            }
            if(information[step_idx].visited){
                reverse_color_circle(information[step_idx].stack);
            }
        }
        //step_idx++;
    }
    private void reverse_highlight_border(StackPane stack){
        Circle circle=(Circle)stack.getChildren().get(0);
        StrokeTransition st=new StrokeTransition(Duration.millis(300),circle);
      //  st.setFromValue(Color.YELLOW);
       // st.setToValue(Color.BLACK);
        st.setFromValue((Color)circle.getStroke());
        st.setToValue(Color.web("#6b8fbf"));
        activeAnimations.add(st);
        st.play();
    }
    private void reverse_highlight_edge(Line edge){
        if(edge == null){
            return;  // nothing to do
        }
        StrokeTransition st=new StrokeTransition(Duration.millis(400),edge);
        //st.setFromValue(Color.YELLOW);
       // st.setToValue(Color.BLACK);
        st.setFromValue((Color)edge.getStroke());
        st.setToValue(Color.web("#6b8fbf"));
        activeAnimations.add(st);
        st.play();
    }
    private void reverse_color_circle(StackPane stack){
        Circle circle=(Circle)stack.getChildren().get(0);
       // FillTransition ft=new FillTransition(Duration.millis(250), circle);
        //ft.setFromValue((Color) circle.getFill());
        //ft.setToValue(Color.LIGHTBLUE);
       // ft.setFromValue(Color.LIMEGREEN);  // soft blue
        //ft.setToValue(Color.);
        circle.setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.web("#e6f4ff")), // very light top
                new Stop(1, Color.web("#bcdcff"))  // soft blue bottom
        ));
       // activeAnimations.add(ft);
       // ft.play();
    }
    private Node delete(Node temp_root,int val){
        if(temp_root==null){
            return temp_root;
        }
        information[info_count] = new Information_bst();
        information[info_count].stack = temp_root.stack;
        information[info_count].edge = temp_root.edge;
        information[info_count++].just_found = true;

        if(val<temp_root.val){
            temp_root.left=delete(temp_root.left,val);
        }
        else if(val>temp_root.val){
            temp_root.right=delete(temp_root.right,val);
        }
        else{
            if(temp_root.left==null && temp_root.right==null){
                information[info_count] = new Information_bst();
                information[info_count].stack = temp_root.stack;
                information[info_count].edge = temp_root.edge;
                information[info_count++].visited= true;
                //delete the leaf node;
                information[info_count] = new Information_bst();
                information[info_count].stack = temp_root.stack;
                information[info_count].edge = temp_root.edge;
                information[info_count++].delete_leaf= true;

                return null;
            }
            else if(temp_root.left==null){
                information[info_count] = new Information_bst();
                information[info_count].stack = temp_root.stack;
                information[info_count].edge = temp_root.edge;
                information[info_count++].visited= true;

                information[info_count] = new Information_bst();
                information[info_count].stack = temp_root.stack;
                information[info_count].edge = temp_root.edge;
                information[info_count].delete_has_right_subtree= true;

                information[info_count].movable_node=new ArrayList<>();
                extract_moving_node(information[info_count].movable_node,temp_root.right);
               /* double dx=temp_root.stack.getLayoutX()-temp_root.right.stack.getLayoutX();
                double dy=temp_root.stack.getLayoutY()-temp_root.right.stack.getLayoutY();*/
                double dx = temp_root.stack.getBoundsInParent().getCenterX()-temp_root.right.stack.getBoundsInParent().getCenterX();
                double dy = temp_root.stack.getBoundsInParent().getCenterY()-temp_root.right.stack.getBoundsInParent().getCenterY();
                information[info_count].dx=dx;
                information[info_count].dy=dy;
                //information[info_count].new_edge=temp_root.edge;
                information[info_count++].deleting_edge=temp_root.right.edge;


                Node temp=temp_root;
                temp_root=temp_root.right;
                temp_root.edge=temp.edge;
                return temp_root;
            }
            else if(temp_root.right==null){
                information[info_count] = new Information_bst();
                information[info_count].stack = temp_root.stack;
                information[info_count].edge = temp_root.edge;
                information[info_count++].visited= true;

                information[info_count] = new Information_bst();
                information[info_count].stack = temp_root.stack;
                information[info_count].edge = temp_root.edge;
                information[info_count].delete_has_left_subtree= true;

                information[info_count].movable_node=new ArrayList<>();
                extract_moving_node(information[info_count].movable_node,temp_root.left);
                /*double dx=temp_root.stack.getLayoutX()-temp_root.left.stack.getLayoutX();
                double dy=temp_root.stack.getLayoutY()-temp_root.left.stack.getLayoutY();*/
                double dx = temp_root.stack.getBoundsInParent().getCenterX()-temp_root.left.stack.getBoundsInParent().getCenterX();
                double dy = temp_root.stack.getBoundsInParent().getCenterY()-temp_root.left.stack.getBoundsInParent().getCenterY();
                information[info_count].dx=dx;
                information[info_count].dy=dy;
                //information[info_count].new_edge=temp_root.edge;
                information[info_count++].deleting_edge=temp_root.left.edge;

                Node temp=temp_root;
                temp_root=temp_root.left;
                temp_root.edge=temp.edge;
                return temp_root;
            }
            else{
                information[info_count] = new Information_bst();
                information[info_count].stack = temp_root.stack;
                information[info_count].edge = temp_root.edge;
                information[info_count].target=true;
                information[info_count++].delete_has_both_subtrees= true;

                Node temp=find_min_node(temp_root.right);

                temp_root.val=temp.val;
                temp_root.right=delete(temp_root.right,temp_root.val);
                return temp_root;
            }
        }
        return temp_root;
    }
    private Node find_min_node(Node temp_root){
        Node p=temp_root;
        Node q=p.parent;
        while(temp_root!=null){
            information[info_count] = new Information_bst();
            information[info_count].stack = p.stack;
            information[info_count].edge = p.edge;
            information[info_count++].just_found = true;

            p=temp_root;
            temp_root=temp_root.left;
        }
        information[info_count] = new Information_bst();
        information[info_count].stack = p.stack;
        information[info_count].edge = p.edge;
        information[info_count++].just_found = true;

        information[info_count] = new Information_bst();
        information[info_count].stack = p.stack;
        information[info_count].edge = p.edge;
        information[info_count++].visited = true;

        information[info_count] = new Information_bst();
        information[info_count].stack = p.stack;
        information[info_count].edge = p.edge;
        information[info_count].p1=q;
        information[info_count].p2=p;
        information[info_count].exchange_data=((Text)q.stack.getChildren().get(1)).getText();
        information[info_count++].exchange_val=true;
        return p;

    }
    private void extract_moving_node(ArrayList<Node> movable_node,Node temp_root){
        if(temp_root==null){
            return;
        }
        movable_node.add(temp_root);
        extract_moving_node(movable_node,temp_root.left);
        extract_moving_node(movable_node,temp_root.right);
    }
    private void start_delete_timeline(){
        if(timeline!=null){
            return;
        }
        bst_container.getChildren().add(currCircle);
        timeline=new Timeline(new KeyFrame(Duration.millis(600), e->delete_step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        step_idx=0;
        timeline.play();
    }
    private void delete_step(){
        if(step_idx<info_count) {
            StackPane stack1 = information[step_idx].stack;
           // currCircle.setCenterX(stack1.getLayoutX() + stack1.getWidth() / 2);
           // currCircle.setCenterY(stack1.getLayoutY() + stack1.getHeight() / 2);
            Bounds b = stack1.getBoundsInParent();

            currCircle.setCenterX(b.getCenterX());
            currCircle.setCenterY(b.getCenterY());
            currCircle.setVisible(true);

            if (information[step_idx].just_found) {
                highlight_edge(information[step_idx].edge);
                highlight_border(information[step_idx].stack);
            }
            if (information[step_idx].visited) {
                color_circle(information[step_idx].stack,"RED");
            }
            if(information[step_idx].target){
                color_circle(information[step_idx].stack,"ORANGE");
            }
            if(information[step_idx].exchange_val){
                Text temp=(Text)information[step_idx].p2.stack.getChildren().get(1);
                String str=temp.getText();
                ((Text)information[step_idx].p1.stack.getChildren().get(1)).setText(str);
            }
            if (information[step_idx].delete_leaf) {
                bst_container.getChildren().remove(information[step_idx].stack);
                bst_container.getChildren().remove(information[step_idx].edge);
                bst_container.getChildren().remove(currCircle);
            }
            if (information[step_idx].delete_has_left_subtree) {
                StackPane stack = information[step_idx].stack;
                double dx = information[step_idx].dx;
                double dy = information[step_idx].dy;
                bst_container.getChildren().remove(information[step_idx].stack);
                bst_container.getChildren().remove(information[step_idx].deleting_edge);
                bst_container.getChildren().remove(currCircle);
                ParallelTransition pt = moveSubtreeParallel(information[step_idx].movable_node, dx, dy);
                pt.play();
            }
            if (information[step_idx].delete_has_right_subtree) {
                StackPane stack = information[step_idx].stack;
                double dx = information[step_idx].dx;
                double dy = information[step_idx].dy;
                bst_container.getChildren().remove(information[step_idx].stack);
                bst_container.getChildren().remove(information[step_idx].deleting_edge);
                bst_container.getChildren().remove(currCircle);
                ParallelTransition pt = moveSubtreeParallel(information[step_idx].movable_node, dx, dy);
                pt.play();
            }

            step_idx++;
        }
    }
    private ParallelTransition moveSubtreeParallel(ArrayList<Node> movable_node,double dx,double dy){
        ParallelTransition parallel = new ParallelTransition();
        for (Node n : movable_node) {
            TranslateTransition move = new TranslateTransition(Duration.millis(500), n.stack);
            move.setByX(dx);
            move.setByY(dy);
            parallel.getChildren().add(move);
        }

        for(int i=1;i<movable_node.size();i++){
            TranslateTransition move = new TranslateTransition(Duration.millis(500), movable_node.get(i).edge);
            move.setByX(dx);
            move.setByY(dy);
            parallel.getChildren().add(move);
        }
        return parallel;
    }
    private void delete_step_prev(){
        if(step_idx > 0) {
            step_idx--; // move to previous step
            Information_bst info = information[step_idx];

            StackPane stack;
            if(step_idx==0){
                stack = information[step_idx].stack;
            }
            else {
                stack = information[step_idx - 1].stack;
            }
           // currCircle.setCenterX(stack.getLayoutX() + stack.getWidth() / 2);
           // currCircle.setCenterY(stack.getLayoutY() + stack.getHeight() / 2);
            Bounds b = stack.getBoundsInParent();

            currCircle.setCenterX(b.getCenterX());
            currCircle.setCenterY(b.getCenterY());
            currCircle.setVisible(true);

            if(info.just_found) {
                reverse_highlight_edge(info.edge);
                reverse_highlight_border(info.stack);
                //unhighlight_border(info.stack);
            }

            if(info.visited) {
                //revert_color_circle(info.stack); // restore original color
                reverse_color_circle(info.stack);
            }
            if(info.target){
                reverse_color_circle(info.stack);
            }

            if(info.exchange_val) {
                ((Text)info.p1.stack.getChildren().get(1)).setText(info.exchange_data);
            }

            if(info.delete_leaf) {
                bst_container.getChildren().add(info.stack);
                bst_container.getChildren().add(info.edge);
                bst_container.getChildren().add(currCircle);
            }

            if(info.delete_has_left_subtree || info.delete_has_right_subtree) {
                ParallelTransition pt = moveSubtreeParallel(info.movable_node, -info.dx, -info.dy);
                pt.play();

                bst_container.getChildren().add(info.stack);
                bst_container.getChildren().add(info.deleting_edge);
                bst_container.getChildren().add(currCircle);
            }
        }
    }
    private void color_circle(StackPane stack,String color){
        Circle circle=(Circle)stack.getChildren().get(0);
        FillTransition ft=new FillTransition(Duration.millis(250), circle);
        //ft.setFromValue((Color) circle.getFill());
        ft.setFromValue(Color.web("#bcdcff"));
        if(color.equals("RED")) {
            ft.setToValue(Color.RED);
        }
        else if(color.equals("ORANGE")){
            ft.setToValue(Color.ORANGE);
        }
        else{
            ft.setToValue(Color.LIMEGREEN);
        }
        activeAnimations.add(ft);
        ft.play();
    }

    @FXML
    private VBox code_pane;

    @FXML
    private void initialize() {
        insert_code();

        legendRow.getChildren().addAll(
                legendItem("Comparing", "compare"),
                legendItem("Current", "current"),
                legendItem("Sorted", "sorted"),
                legendItem("Pivot", "pivot")
        );

    }
    @FXML
    private HBox legendRow;
    private HBox legendItem(String name, String colorClass) {

        Region rect = new Region();
        rect.getStyleClass().addAll("legend-rect", colorClass);

        Label label = new Label(name);
        label.getStyleClass().add("legend-text");

        HBox item = new HBox(6, rect, label);
        item.setAlignment(Pos.CENTER_LEFT);

        return item;
    }
    private void insert_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "void insert(Node* root,int newNode){",
                "Node* y=nullptr;",
                "Node* x=root;",
                "while(x!=nullptr){",
                "   y=x;",
                "   if(newNode->key<root->key){",
                "       x=x->left;",
                "   }",
                "   else{",
                "       x=x->right;",
                "   }",
                "}",
                "if(y==nullptr){",
                "   root=newNode;",
                "}",
                "else if(newNode->key<y->key){",
                "   root->left=newNode;",
                "}",
                "else{",
                "   y->right=newNode;",
                "}"
        };
        set_code(code);
    }
    private void search_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "bool search(Node* root,int key){",
                "   if(root==nullptr || root->key==key){",
                "      return true;",
                "   }",
                "   if(key<root->key){",
                "      return search(root->left,key);",
                "   }",
                "   else{",
                "      return search(root->right,key);",
                "   }",
                "}"
        };
        set_code(code);
    }
    private void minimum_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "Node* minimum(Node* root){",
                "   Node* temp=root;",
                "   if(root==nullptr){",
                "      return nullptr;",
                "   }",
                "   while(temp->left!=nullptr){",
                "      temp=temp->left;",
                "   }",
                "   return temp;",
                "}"
        };
        set_code(code);
    }
    private void maximum_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "Node* maximum(Node* root){",
                "   Node* temp=root;",
                "   if(root==nullptr){",
                "      return nullptr;",
                "   }",
                "   while(temp->right!=nullptr){",
                "      temp=temp->right;",
                "   }",
                "   return temp;",
                "}"
        };
        set_code(code);
    }
    @FXML
    private void home_btn_clicked(ActionEvent event)throws IOException {
        reset_btn_clicked();
        Parent root= FXMLLoader.load(getClass().getResource("menu_scene.fxml"));
        Stage stage=(Stage)((javafx.scene.Node)event.getSource()).getScene().getWindow();
        Scene scene=new Scene(root);
        String css=this.getClass().getResource("menu.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    private void set_code(String[] code){
        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }
    }
    private void predecessor_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "Node* predecessor(Node* root){",
                "   if(root->left!=nullptr){",
                "      return maximum(root->left);",
                "   }",
                "   Node* temp=root;",
                "   Node* y=temp->parent;",
                "   while(y!=nullptr && temp==y->left){",
                "      temp=y;",
                "      y=y->parent;",
                "   }",
                "   return y;",
                "}"
        };
        set_code(code);
    }
    private void successor_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "Node* successor(Node* root){",
                "   if(root->right!=nullptr){",
                "      return minimum(root->right);",
                "   }",
                "   Node* temp=root;",
                "   Node* y=temp->parent;",
                "   while(y!=nullptr && temp==y->right){",
                "      temp=y;",
                "      y=y->parent;",
                "   }",
                "   return y;",
                "}"
        };
        set_code(code);
    }
    private void delete_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "Node* delete(Node* root,int key){",
                "   if(root==NULL){",
                "      return root;",
                "   }",
                "   else if(key<root->key){",
                "      root->left=delete(root->left,key);",
                "   }",
                "   else if(key>root->key){",
                "      root->right=delete(root->right,key);",
                "   }",
                "   else{",
                "      if(root->left==NULL && root->right==NULL){",
                "         delete root;",
                "         return NULL;",
                "      }",
                "      else if(root->left==NULL){",
                "         Node* temp=root;",
                "         root=root->right;",
                "         delete temp;",
                "         return root;",
                "      }",
                "      else if(root->right==NULL){",
                "         Node* temp=root;",
                "         root=root->left;",
                "         delete temp;",
                "         return root;",
                "      }",
                "      else{",
                "         Node* temp=minimum(root->right);",
                "         root->key=temp->key;",
                "         root->value=temp->value;",
                "         root->right=delete(root->right,temp->key);",
                "         return root;",
                "      }",
                "   }",
                "}"
        };
        set_code(code);
    }
    private void inorder_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "void inorder(Node* root){",
                "   if(root==nullptr){",
                "      return;",
                "   }",
                "   inorder(root->left);",
                "   visit(root);",
                "   inorder(root->right);",
                "}"
        };
        set_code(code);
    }
    private void preorder_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "void preorder(Node* root){",
                "   if(root==nullptr){",
                "      return;",
                "   }",
                "   visit(root);",
                "   preorder(root->left);",
                "   preorder(root->right);",
                "}"
        };
        set_code(code);
    }
    private void postorder_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "",
                "void postorder(Node* root){",
                "   if(root==nullptr){",
                "      return;",
                "   }",
                "   postorder(root->left);",
                "   postorder(root->right);",
                "   visit(root);",
                "}"
        };
        set_code(code);
    }





}
