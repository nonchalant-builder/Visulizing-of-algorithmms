package com.example.dsavisualization;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

public class OpeningSceneController2 {

    @FXML private Label titleLabel;
    @FXML private Pane progressBar;
    @FXML private Label loadingLabel;
    @FXML private Button start_btn; // Added from your second snippet

    private Stage stage;
    private Scene scene;
    private Parent root;

    private static final double SPLASH_DURATION = 6000;

    @FXML
    public void initialize() {
        // Initially hide the start button if you want them to wait for loading
        if (start_btn != null) {
            start_btn.setOpacity(0);
            start_btn.setDisable(true);
        }

        progressBar.setPrefWidth(0);
        javafx.application.Platform.runLater(this::runSplash);
    }

    private void runSplash() {
        titleLabel.setOpacity(0);

        // Fade in title
        Timeline fadeIn = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(titleLabel.opacityProperty(), 0)),
                new KeyFrame(Duration.millis(800), new KeyValue(titleLabel.opacityProperty(), 1.0))
        );

        // Progress bar animation
        Timeline progress = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(progressBar.prefWidthProperty(), 0)),
                new KeyFrame(Duration.millis(SPLASH_DURATION - 400), new KeyValue(progressBar.prefWidthProperty(), 400))
        );

        // Dynamic loading text
        String[] loadingMessages = {"Loading...", "Setting up visualizer...", "Preparing data structures...", "Almost ready..."};
        Timeline loadingText = new Timeline();
        for (int i = 0; i < loadingMessages.length; i++) {
            final String msg = loadingMessages[i];
            loadingText.getKeyFrames().add(
                    new KeyFrame(Duration.millis((SPLASH_DURATION / loadingMessages.length) * i),
                            e -> loadingLabel.setText(msg))
            );
        }

        // Completion logic
        Timeline onFinish = new Timeline(
                new KeyFrame(Duration.millis(SPLASH_DURATION), e -> {
                    loadingLabel.setText("Ready!");
                    if (start_btn != null) {
                        // Reveal the start button instead of switching automatically
                        start_btn.setDisable(false);
                        start_btn.setOpacity(1.0);
                    } else {
                        // Fallback: if no button exists, switch automatically
                        switchToMenu(null);
                    }
                })
        );

        fadeIn.play();
        progress.play();
        loadingText.play();
        onFinish.play();
    }

    @FXML
    public void opening_to_menu(ActionEvent event) throws IOException {
        switchToMenu(event);
    }

    private void switchToMenu(ActionEvent event) {
        try {
            // Updated path to use your specific project structure
            FXMLLoader loader = new FXMLLoader(getClass().getResource("menu_scene.fxml"));
            root = loader.load();

            // Get the stage from the event source OR the existing progress bar
            if (event != null) {
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            } else {
                stage = (Stage) progressBar.getScene().getWindow();
            }

            scene = new Scene(root, 1550, 750);

            // Adding CSS logic from your second snippet
            String css = getClass().getResource("menu.css").toExternalForm();
            scene.getStylesheets().add(css);

            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            System.err.println("Error loading menu scene: " + e.getMessage());
            e.printStackTrace();
        }
    }
}