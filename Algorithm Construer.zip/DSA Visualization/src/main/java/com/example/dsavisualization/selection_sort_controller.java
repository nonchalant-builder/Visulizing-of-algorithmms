package com.example.dsavisualization;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.Random;
class Information{
    int i;
    int j;
    int min_idx;
    boolean swaped=false;
    boolean end=false;
}

public class selection_sort_controller {
    @FXML
    HBox bar_container;
    private Rectangle[] bars;
    private Timeline timeline;
    private int step_idx=0;
    @FXML
    private TextField array_element;
    private int []array;
    private int size;

    private int i,j;
    private int min_idx;
    private Information[] information=new Information[1000];

    @FXML
    private void set_array_by_user() {
        if(timeline!=null){
            return;
        }
        String element_text = array_element.getText().trim();
        String[] elements = element_text.split("\\s+");
        array_element.clear();

        if (element_text.isEmpty() || !element_text.matches("^[0-9\\s]+$")) {
            return;
        }
        try {
            size = elements.length;
            array = new int[size];
            for (int i = 0; i < size; i++) {
                array[i] = Integer.parseInt(elements[i]);
            }
            set_bars();
        }catch (NumberFormatException e){
            System.out.println("error in input");
        }
    }

    @FXML
    private void set_array_by_random() {
        if(timeline!=null){
            return;
        }
        size = 20; // you can change this or make it from a Slider input

        array = new int[size];
        Random rand = new Random();

        // Fill array with random numbers (e.g., 20 to 300 for bar height)
        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(281) + 20; // random between 20-300
        }
        set_bars();
    }

    private void set_information(){
        int k=0;
        for(i=0;i<array.length-1;i++){
            min_idx=i;
            for(j=i+1;j<array.length;j++){
                if(array[j]<array[min_idx]){
                    min_idx=j;
                }
                information[k]=new Information();
                information[k].i=i;
                information[k].j=j;
                information[k].min_idx=min_idx;
                k++;
            }
            int temp=array[i];
            array[i]=array[min_idx];
            array[min_idx]=temp;
            information[k-1].swaped=true;
        }
        information[k]=new Information();
        information[k].end=true;
    }

   private void set_bars() {
       bar_container.getChildren().clear();
       bars = new Rectangle[size]; // We still keep the rectangle array for easy height access

       for (int i = 0; i < size; i++) {
           // 1. Create the Rectangle
           Rectangle bar = new Rectangle();
           bar.setWidth(30);
           bar.setHeight(array[i]);
           bar.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                   new Stop(0, Color.LIGHTSKYBLUE),
                   new Stop(1, Color.SKYBLUE)));
           bar.setArcWidth(4);
           bar.setArcHeight(4);
           bars[i] = bar;

           // 2. Create the Text label
           Text text = new Text(String.valueOf(array[i]));
           text.setFill(Color.BLACK);
           text.setStyle("-fx-font-size: 10px;-fx-font-weight: bold;"); // Adjust size so it fits

           // 3. Wrap them in a StackPane
           StackPane stack = new StackPane();
           stack.getChildren().addAll(bar, text);
           stack.setAlignment(Pos.BOTTOM_CENTER); // Align text at the bottom or center

           bar_container.getChildren().add(stack);
       }
   }

    @FXML
    private void start_sorting(){
        if(timeline!=null){
            return;
        }
        if(array==null || array.length==0){
            return;
        }
        set_information();
        step_idx=0;
        timeline=new Timeline(new KeyFrame(Duration.millis(300),e->step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void step(){
        if(step_idx>=information.length  || information[step_idx] == null){
            timeline.stop();
            return;
        }
        if(information[step_idx].end==true){
            make_all_bar_green();
            timeline.stop();
            return;
        }
        for(int i=0;i<information[step_idx].i;i++){
            bars[i].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
        for(int i=information[step_idx].i;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
        bars[information[step_idx].i].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));
        bars[information[step_idx].j].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.GOLD),       // light top
                new Stop(1, Color.ORANGE)      // deeper bottom
        ));
        bars[information[step_idx].min_idx].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));

        if(information[step_idx].swaped==true){

            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].i);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].min_idx);

            // Get the Text nodes from the StackPanes (index 1 because Rect is index 0)
            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            // Swap Heights (using your existing logic)
            double tempHeight = bars[information[step_idx].i].getHeight();
            bars[information[step_idx].i].setHeight(bars[information[step_idx].min_idx].getHeight());
            bars[information[step_idx].min_idx].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);
        }
        step_idx++;

    }

    @FXML
    private void pause_sorting(){
       if(timeline!=null){
           timeline.pause();
       }
    }
    @FXML
    private void resume_sorting(){
       if(timeline!=null && timeline.getStatus()== Animation.Status.PAUSED){
           timeline.play();
       }
    }
    @FXML
    private  void reset_sorting(){
       if(timeline!=null){
           timeline.stop();
           timeline=null;
       }
        bar_container.getChildren().clear();
    }
    @FXML
    private void speed_up(){
       if(timeline!=null){
           double curr_rate=timeline.getCurrentRate();
           if(curr_rate<2){
               timeline.setRate(curr_rate+.5);
           }
       }
    }
    @FXML
    private void speed_down(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate>.5){
                timeline.setRate(curr_rate-.5);
            }
        }
    }
    @FXML
    private void next_step(){
       if(timeline!=null){
           if(timeline.getStatus()==Animation.Status.PAUSED){
               step();
           }
       }
    }
    @FXML
    private void previous_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step_prev();
            }
        }
    }
    private void step_prev(){
       step_idx--;
        if(step_idx>=information.length  || information[step_idx] == null || step_idx<0){
            timeline.stop();
            return;
        }
        if(information[step_idx].end==true){
            timeline.stop();
            return;
        }
        for(int i=0;i<information[step_idx].i;i++){
            bars[i].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
        for(int i=information[step_idx].i;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
        bars[information[step_idx].i].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));
        bars[information[step_idx].j].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.GOLD),       // light top
                new Stop(1, Color.ORANGE)      // deeper bottom
        ));
        bars[information[step_idx].min_idx].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));


        if(information[step_idx].swaped==true){

            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].i);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].min_idx);

            // Get the Text nodes from the StackPanes (index 1 because Rect is index 0)
            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            // Swap Heights (using your existing logic)
            double tempHeight = bars[information[step_idx].i].getHeight();
            bars[information[step_idx].i].setHeight(bars[information[step_idx].min_idx].getHeight());
            bars[information[step_idx].min_idx].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);
        }
    }
    private void make_all_bar_green(){
        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
    }
    @FXML
    private VBox code_pane;

    @FXML
    private void initialize() {

        bar_container.setAlignment(Pos.BOTTOM_CENTER);
        bar_container.setSpacing(5);

        String[] code = {
                " ",
                " ",
                "int n=arr.size();",
                " ",
                "for(int i=0;i<n;i++){",
                "   int minIdx=i;",
                "   for(int j=i+1;j<n-i-1;j++){",
                "      if(arr[j] < arr[minIdx]){",
                "         minIdx=j;",
                "      }",
                "      int temp = arr[j];",
                "      arr[j] = arr[minIdx];",
                "      arr[minIdx] = temp;",
                "   }",
                "}"
        };

        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }

        legendRow.getChildren().addAll(
                legendItem("i", "red"),
                legendItem("minIdx", "red"),
                legendItem("j", "yellow"),
                legendItem("sorted", "green")
        );

    }
    @FXML
    private HBox legendRow;
    private HBox legendItem(String name, String colorClass) {

        Region rect = new Region();
        rect.getStyleClass().addAll("legend-rect", colorClass);

        Label label = new Label(name);
        label.getStyleClass().add("legend-text");

        HBox item = new HBox(6, rect, label);
        item.setAlignment(Pos.CENTER_LEFT);

        return item;
    }

}
