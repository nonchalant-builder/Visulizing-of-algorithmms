package com.example.dsavisualization;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

class Information_merge{
    int lo;
    int hi;
    int left;
    int right;
    int mid_left;
    int mid_right;
    int move_down_idx;
    int merge_count;
    boolean sorted_arr_ready=false;
    boolean unsorted_arr_ready=false;
    boolean move_down=false;
    boolean move_up=false;
    boolean end=false;
    ArrayList<Integer> sorted_arr;
    ArrayList<Integer> unsorted_arr;
}

public class merge_sort_controller2 {
    private int array[];
    private int size;
    private int k;

    @FXML
    Pane bar_container;
    private double start_x;
    //private Rectangle[] bars;
    @FXML
    private TextField array_element;
    private Timeline timeline;

    private int step_idx=0;
    private Information_merge[] information=new Information_merge[100000];

    @FXML
    private void set_array_by_user() {
        if(timeline!=null){
            return;
        }
        String element_text = array_element.getText().trim();
        String[] elements = element_text.split("\\s+");
        array_element.clear();

        if (element_text.isEmpty() || !element_text.matches("^[0-9\\s]+$")) {
            return;
        }
        try {
            size = elements.length;
            array = new int[size];
            for (int i = 0; i < size; i++) {
                array[i] = Integer.parseInt(elements[i]);
            }
            set_bars();
        }catch (NumberFormatException e){
            System.out.println("error in input");
        }
    }

    @FXML
    private void set_array_by_random() {
        if(timeline!=null){
            return;
        }
        size = 20;

        array = new int[size];
        Random rand = new Random();

        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(281) + 20;
        }
        set_bars();
    }
    private void set_information(){
        merge_sort(0,size);

        information[k]=new Information_merge();
        information[k].end=true;
    }
    void merge_sort(int lo,int hi){
        if((hi-lo)<=1){
            return;
        }
        int mid=lo+(hi-lo)/2;
        merge_sort(lo,mid);
        merge_sort(mid,hi);
        merge(lo,mid,hi);
    }
    void merge(int lo,int mid,int hi){
        int []merged=new int[hi-lo];
        int left=lo;
        int right=mid;
        int c=0;
        while(left<mid && right<hi){
            information[k]=new Information_merge();
            information[k].lo=lo;
            information[k].hi=hi;
            information[k].mid_left=mid;
            information[k].mid_right=mid;
            information[k].left=left;
            information[k].right=right;
            information[k].move_down=true;

            if(array[left]<array[right]){
                information[k].move_down_idx=left;
                information[k].merge_count=c;

                merged[c++]=array[left++];
            }
            else{
                information[k].move_down_idx=right;
                information[k].merge_count=c;

                merged[c++]=array[right++];
            }
            k++;
        }
        while(left<mid){
            information[k]=new Information_merge();
            information[k].lo=lo;
            information[k].hi=hi;
            information[k].mid_left=mid;
            information[k].mid_right=mid;
            information[k].left=left;
            information[k].right=right;
            information[k].move_down=true;
            information[k].move_down_idx=left;
            information[k].merge_count=c;
            k++;

            merged[c++]=array[left++];
        }
        while(right<hi){
            information[k]=new Information_merge();
            information[k].lo=lo;
            information[k].hi=hi;
            information[k].mid_left=mid;
            information[k].mid_right=mid;
            information[k].left=left;
            information[k].right=right;
            information[k].move_down=true;
            information[k].move_down_idx=right;
            information[k].merge_count=c;
            k++;

            merged[c++]=array[right++];
        }
        information[k]=new Information_merge();
        information[k].lo=lo;
        information[k].hi=hi;
        information[k].unsorted_arr=new ArrayList<>(size);
        information[k].unsorted_arr_ready=true;
        for(int i=0;i<size;i++){
            information[k].unsorted_arr.add(array[i]);
        }
        k++;
        for(int i=0;i<(hi-lo);i++){
            array[lo+i]=merged[i];
        }
        information[k]=new Information_merge();
        information[k].lo=lo;
        information[k].hi=hi;
        information[k].sorted_arr=new ArrayList<>(size);
        information[k].sorted_arr_ready=true;
        for(int i=0;i<size;i++){
            information[k].sorted_arr.add(array[i]);
        }
        information[k].move_up=true;
        k++;

    }
    private void set_bars(){
        bar_container.getChildren().clear();
        double baseY=350;
        int starting_bar_point=(850-(size*35))/2;
        start_x=starting_bar_point;

        for(int i=0;i<size;i++){
            Rectangle bar=new Rectangle();
            bar.setWidth(30);
            bar.setHeight(array[i]);
            bar.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
            bar.setArcWidth(4);
            bar.setArcHeight(4);

            Text text=new Text(String.valueOf(array[i]));
            text.setFill(Color.BLACK);
            text.setStyle("-fx-font-size: 10px;-fx-font-weight: bold;");

            StackPane stack=new StackPane();
            stack.getChildren().addAll(bar,text);
            stack.setAlignment(Pos.BOTTOM_CENTER);

            stack.setLayoutX(starting_bar_point);
            stack.setLayoutY(baseY-array[i]);

            starting_bar_point+=35;
            stack.setUserData(i);

            bar_container.getChildren().add(stack);
        }
    }
    @FXML
    private void start_sorting(){
        if(timeline!=null){
            return;
        }
        if(array==null || array.length==0){
            return;
        }
        k=0;
        set_information();
        step_idx=0;
        timeline=new Timeline(new KeyFrame(Duration.millis(300), e->step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }
    private void step(){
        if(step_idx>=k){
            make_all_bar_green();
            timeline.stop();
            return;
        }
        if(information[step_idx].end==true){
            make_all_bar_green();
            timeline.stop();
            return;
        }
        for(int i=0;i<size;i++){
            StackPane stack=(StackPane) bar_container.getChildren().get(i);
            Rectangle bar=(Rectangle)stack.getChildren().get(0);
            bar.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
        if(information[step_idx].left<size) {
            StackPane stack = (StackPane) bar_container.getChildren().get(information[step_idx].left);
            Rectangle bar = (Rectangle) stack.getChildren().get(0);
            bar.setFill(new LinearGradient(
                    0, 0, 0, 1,  // vertical gradient
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.SALMON),    // lighter red at top
                    new Stop(1, Color.DARKRED)    // darker red at bottom
            ));
        }
        if(information[step_idx].right<size) {
            StackPane stack = (StackPane) bar_container.getChildren().get(information[step_idx].right);
            Rectangle bar = (Rectangle) stack.getChildren().get(0);
            bar.setFill(new LinearGradient(
                    0, 0, 0, 1,  // vertical gradient
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.SALMON),    // lighter red at top
                    new Stop(1, Color.DARKRED)    // darker red at bottom
            ));
        }
        if(information[step_idx].move_down==true){
            int moving_bar_idx=information[step_idx].move_down_idx;
            if(moving_bar_idx >= size){
                step_idx++;
                return;
            }
            StackPane moving_stack=(StackPane) bar_container.getChildren().get(moving_bar_idx);
            moving_stack.setTranslateX(0);
            moving_stack.setTranslateY(0);
            Information_merge ob=information[step_idx];
            //double down_point_x=(ob.lo*35)+((ob.left-ob.lo)+(ob.right- ob.mid_right))*35;
            double down_point_x=start_x+(ob.lo+ob.merge_count)*35;
          //  double current_x= moving_stack.getLayoutX()+moving_stack.getTranslateX();;

            TranslateTransition down=new TranslateTransition(Duration.millis(300),moving_stack);
            down.setToX(down_point_x-moving_stack.getLayoutX());
            down.setByY(150);
            down.play();
        }
        if(information[step_idx].move_up==true){
            if(information[step_idx].sorted_arr_ready==true){
                sort(information[step_idx].lo,information[step_idx].hi);

                for(int i=information[step_idx].lo;i<information[step_idx].hi;i++){
                    StackPane stack = (StackPane) bar_container.getChildren().get(i);
                    TranslateTransition up=new TranslateTransition(Duration.millis(300),stack);
                    up.setByX(0);
                    up.setByY(-150);
                    up.play();
                }
            }
        }
        step_idx++;
    }
   /* private void sort(int lo,int hi){
        for(int i=lo;i<hi;i++){
            int value = information[step_idx].sorted_arr.get(i);

            for(Node node : bar_container.getChildren()){
                StackPane st = (StackPane) node;
                Rectangle r = (Rectangle) st.getChildren().get(0);

                if(r.getHeight() == value){
                    bar_container.getChildren().remove(st);
                    bar_container.getChildren().add(i, st);
                    break;
                }
            }
        }
    }*/
    @FXML
    private void pause_sorting(){
        if(timeline!=null){
            timeline.pause();
        }
    }
    @FXML
    private void resume_sorting(){
        if(timeline!=null && timeline.getStatus()== Animation.Status.PAUSED){
            timeline.play();
        }
    }
    @FXML
    private  void reset_sorting(){
        if(timeline!=null){
            timeline.stop();
            timeline=null;
        }
        bar_container.getChildren().clear();
    }
    @FXML
    private void speed_up(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate<2){
                timeline.setRate(curr_rate+.5);
            }
        }
    }
    @FXML
    private void speed_down(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate>.5){
                timeline.setRate(curr_rate-.5);
            }
        }
    }
    @FXML
    private void next_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step();
            }
        }
    }
    @FXML
    private void previous_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step_prev();
            }
        }
    }

  /* private void step_prev() {

   }*/


    private void make_all_bar_green(){
        for(int i=0;i<size;i++){
            StackPane stack=(StackPane) bar_container.getChildren().get(i);
            Rectangle bar=(Rectangle)stack.getChildren().get(0);
            bar.setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
    }
    @FXML
    private VBox code_pane;

    @FXML
    private void initialize() {
        String[] code = {
               "void mergeSort(int l,int h){",
                "  if(h-l<=1){",
                "     return;",
                "  }",
                "  int mid=(l+h)/2;",
                "  mergeSort(l,mid);",
                "  mergeSort(mid,h);",
                "  merge(l,mid,h);",
                "}",
                "",
                "void merge(int l,int m,int h){",
                "   int merged=new int[h-l];",
                "   int left=l;",
                "   int right=mid;",
                "   int k=0,mid=m;",
                "   while(left<mid && right<h){",
                "      if(arr[left]<arr[right]){",
                "         merged[k++]=",
                "                 arr[left++];",
                "      }",
                "      else{",
                "         merged[k++]=",
                "                 arr[right++];",
                "      }",
                "   }",
                "   while(left<mid){",
                "      merged[k++]=arr[left++];",
                "   }",
                "   while(right<h){",
                "      merged[k++]=arr[right++];",
                "   }",
                "   for(int i=0;i<hi-lo;i++){",
                "      arr[i+l]=merged[i];",
                "   }",
                "   delete []merged;",
                "}"

        };

        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }

        legendRow.getChildren().addAll(
                legendItem("left", "red"),
                legendItem("right", "red"),
                legendItem("sorted", "green")
        );

    }
    @FXML
    private HBox legendRow;
    private HBox legendItem(String name, String colorClass) {

        Region rect = new Region();
        rect.getStyleClass().addAll("legend-rect", colorClass);

        Label label = new Label(name);
        label.getStyleClass().add("legend-text");

        HBox item = new HBox(6, rect, label);
        item.setAlignment(Pos.CENTER_LEFT);

        return item;
    }
    // Then in sort():
    private void sort(int lo, int hi){
        for(int i = lo; i < hi; i++){
            int value = information[step_idx].sorted_arr.get(i);

            for(int j = i; j < bar_container.getChildren().size(); j++){
                StackPane st = (StackPane) bar_container.getChildren().get(j);
                Rectangle r = (Rectangle) st.getChildren().get(0);

                if(r.getHeight() == value){
                    // swap by index, not by remove+add blindly
                    bar_container.getChildren().remove(j);
                    bar_container.getChildren().add(i, st);
                    break;
                }
            }
        }
    }
    private void step_prev() {
        if (step_idx <= 0) return;

        // Go back two steps (one for the decrement, one because step() increments at the end)
        step_idx = Math.max(0, step_idx - 1);

        // Reset all bars to original positions and colors
        rebuildBarsFromSnapshot();

        // Replay all steps up to current step_idx visually
        replayUpTo(step_idx);
    }

    private void rebuildBarsFromSnapshot() {
        // Clear all translate transforms on every bar
        for (int i = 0; i < bar_container.getChildren().size(); i++) {
            StackPane stack = (StackPane) bar_container.getChildren().get(i);
            stack.setTranslateX(0);
            stack.setTranslateY(0);
        }

        // Find the most recent sorted_arr snapshot before step_idx
        // and reorder bars to match that state
        int lastSortedStep = -1;
        for (int i = step_idx - 1; i >= 0; i--) {
            if (information[i] != null && information[i].sorted_arr_ready) {
                lastSortedStep = i;
                break;
            }
        }

        if (lastSortedStep == -1) {
            // No sort has happened yet, restore original bar order
            // by reordering to match unsorted state
            restoreOriginalOrder();
        } else {
            // Reorder bars to match the last sorted snapshot
            int lo = information[lastSortedStep].lo;
            int hi = information[lastSortedStep].hi;
            reorderBars(lastSortedStep, lo, hi);
        }

        // Reset all bar colors to default blue
        for (int i = 0; i < bar_container.getChildren().size(); i++) {
            StackPane stack = (StackPane) bar_container.getChildren().get(i);
            Rectangle bar = (Rectangle) stack.getChildren().get(0);
            bar.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
    }

    private void reorderBars(int snapStep, int lo, int hi) {
        for (int i = lo; i < hi; i++) {
            int value = information[snapStep].sorted_arr.get(i);

            for (int j = i; j < bar_container.getChildren().size(); j++) {
                StackPane st = (StackPane) bar_container.getChildren().get(j);
                Rectangle r = (Rectangle) st.getChildren().get(0);

                if ((int) r.getHeight() == value && (int) st.getUserData() != -1) {
                    bar_container.getChildren().remove(j);
                    bar_container.getChildren().add(i, st);
                    break;
                }
            }
        }
    }

    private void restoreOriginalOrder() {
        // Sort bar_container children back to original index order using userData
        ArrayList<StackPane> panes = new ArrayList<>();
        for (javafx.scene.Node node : bar_container.getChildren()) {
            panes.add((StackPane) node);
        }

        panes.sort(Comparator.comparingInt(sp -> (int) sp.getUserData()));

        bar_container.getChildren().clear();
        bar_container.getChildren().addAll(panes);

        // Restore layout positions
        double starting_bar_point = start_x;
        for (javafx.scene.Node node : bar_container.getChildren()) {
            StackPane stack = (StackPane) node;
            int idx = (int) stack.getUserData();
            stack.setLayoutX(start_x + idx * 35);
            stack.setTranslateX(0);
            stack.setTranslateY(0);
        }
    }

    private void replayUpTo(int targetStep) {
        // Re-apply move_down translations for all steps up to targetStep
        // without animation (instant repositioning)
        for (int s = 0; s < targetStep; s++) {
            if (information[s] == null || information[s].end) break;

            if (information[s].move_down) {
                int moving_bar_idx = information[s].move_down_idx;
                if (moving_bar_idx >= size) continue;

                StackPane moving_stack = (StackPane) bar_container.getChildren().get(moving_bar_idx);
                Information_merge ob = information[s];
                double down_point_x = start_x + (ob.lo + ob.merge_count) * 35;

                moving_stack.setTranslateX(down_point_x - moving_stack.getLayoutX());
                moving_stack.setTranslateY(150);
            }

            if (information[s].move_up && information[s].sorted_arr_ready) {
                for (int i = information[s].lo; i < information[s].hi; i++) {
                    StackPane stack = (StackPane) bar_container.getChildren().get(i);
                    stack.setTranslateX(0);
                    stack.setTranslateY(0);
                }
            }
        }
    }
}
