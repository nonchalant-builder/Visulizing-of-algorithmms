package com.example.dsavisualization;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.stage.Stage;

import java.io.IOException;


public class menu_scene_controller {
    private Stage stage;
    private Scene scene;
    private Parent root;

    public void sorting_algorithm_btn_clicked(ActionEvent event)throws IOException {
        root= FXMLLoader.load(getClass().getResource("sortingAlgorithm.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("sorting.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void search_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("LinearSearch.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("search.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void tree_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("bst2.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("bst.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void graph_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("graph.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("graph.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void stack_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("Stack.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("stack.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void queue_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("Queue.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("stack.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void heap_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("Heap.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("stack.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void lcs_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("lcs.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("graph.css").toExternalForm();
       scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void about_us_btn_clicked(ActionEvent event)throws IOException{
        root=FXMLLoader.load(getClass().getResource("about.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        //String css=this.getClass().getResource("graph.css").toExternalForm();
        //scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    private Button sorting_menu_btn;
    @FXML
    private Button search_btn;
    @FXML
    private void initialize(){

    }
}
