package com.example.dsavisualization;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class StartApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(StartApplication.class.getResource("Opening2.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1550, 750);
        stage.setTitle("DSA Visualization");
        //String css=this.getClass().getResource("Opening.css").toExternalForm();
        //scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
}

