package com.example.dsavisualization;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
class Information3{
    int i;
    int j;
    int move_idx=-1;
    int move_up_left;
    int move_up_right;
    int move_down_x;
    boolean move_down=false;
    boolean move_up=false;
    //boolean swaped=false;
    boolean end=false;
    int []arr;
    int l;
    int mid;
    int l1;
    int mid1;
}

public class merge_sort_controller {
    @FXML
    Pane bar_container;
    private Rectangle[] bars;
    private Timeline timeline;
    private int step_idx=0;
    @FXML
    private TextField array_element;
    private int []array;
    private int size;
    private int k;
    //int starting_x;

    private Information3[] information=new Information3[100000];

    @FXML
    private void set_array_by_user() {
        if(timeline!=null){
            return;
        }
        String element_text = array_element.getText();
        String[] elements = element_text.split("\\s+");
        size = elements.length;
        array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = Integer.parseInt(elements[i]);
        }
        set_bars();
    }

    @FXML
    private void set_array_by_random() {
        if(timeline!=null){
            return;
        }
        size = 20; // you can change this or make it from a Slider input

        array = new int[size];
        Random rand = new Random();

        // Fill array with random numbers (e.g., 20 to 300 for bar height)
        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(281) + 20; // random between 20-300
        }
        set_bars();
    }

    private void set_information(){
        merge_sort(0,size);

        information[k]=new Information3();
        information[k].end=true;
    }
    void merge_sort(int lo,int hi){
        if((hi-lo)<=1){
            return;
        }
        int mid=lo+(hi-lo)/2;
        merge_sort(lo,mid);
        merge_sort(mid,hi);
        merge(lo,mid,hi);
    }
    void merge(int lo,int mid,int hi){
        int merged[]=new int[hi-lo];
        int left=lo;
        int right=mid;
        int c=0;
        while(left<mid && right<hi){
            information[k]=new Information3();
            //information[k].arr=new int[size];
            information[k].i=left;
            information[k].j=right;
            information[k].move_down_x=lo;
            if(array[left]<array[right]){
                information[k].move_down=true;
                information[k].move_idx=left;
                information[k].l=lo;
                information[k].l1=left;
                information[k].mid=mid;
                information[k].mid1=right;
                k++;
                merged[c++]=array[left++];
            }
            else{
                information[k].move_down=true;
                information[k].move_idx=right;
                information[k].l=lo;
                information[k].l1=left;
                information[k].mid=mid;
                information[k].mid1=right;
                k++;
                merged[c++]=array[right++];
            }
        }
        while(left<mid){
            information[k]=new Information3();
           // information[k].arr=new int[size];
            information[k].i=left;
            information[k].j=left;
            information[k].move_idx=left;
            information[k].move_down=true;
            information[k].move_down_x=lo;
            information[k].l=lo;
            information[k].l1=left;
            information[k].mid=mid;
            information[k].mid1=right;
            k++;
            merged[c++]=array[left++];
        }
        while(right<hi){
            information[k]=new Information3();
           // information[k].arr=new int[size];
            information[k].i=right;
            information[k].j=right;
            information[k].move_idx=right;
            information[k].move_down=true;
            information[k].move_down_x=lo;
            information[k].l=lo;
            information[k].l1=left;
            information[k].mid=mid;
            information[k].mid1=right;
            k++;
            merged[c++]=array[right++];
        }
        information[k]=new Information3();
        information[k].arr=new int[size];
        for(int i=0;i<size;i++){
            information[k].arr[i]=array[i];
        }
        information[k].move_up=true;
        information[k].move_up_left=lo;
        information[k].move_up_right=hi-1;
        information[k].move_down_x=lo;
        k++;

        for(int i=0;i<(hi-lo);i++){
            array[lo+i]=merged[i];
        }
    }

    private void set_bars() {
        bar_container.getChildren().clear();
        bars = new Rectangle[size]; // We still keep the rectangle array for easy height access
        double baseY = 400;

        int starting_point=(1170-(size*30))/2;

        for (int i = 0; i < size; i++) {
            // 1. Create the Rectangle
            Rectangle bar = new Rectangle();

            bar.setWidth(30);
            bar.setHeight(array[i]);
            bar.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
            bar.setArcWidth(4);
            bar.setArcHeight(4);
            bars[i] = bar;

            // 2. Create the Text label
            Text text = new Text(String.valueOf(array[i]));
            text.setFill(Color.BLACK);
            text.setStyle("-fx-font-size: 10px;-fx-font-weight: bold;"); // Adjust size so it fits

            // 3. Wrap them in a StackPane
            StackPane stack = new StackPane();
            stack.getChildren().addAll(bar, text);
            stack.setAlignment(Pos.BOTTOM_CENTER); // Align text at the bottom or center

            stack.setLayoutX(starting_point);
            //stack.setLayoutY(330);
            stack.setLayoutY(baseY - array[i]);
            starting_point=starting_point+35;

            bar_container.getChildren().add(stack);

        }
    }

    @FXML
    private void start_sorting(){
        if(timeline!=null){
            return;
        }
        k=0;
        set_information();
        step_idx=0;
        timeline=new Timeline(new KeyFrame(Duration.millis(300),e->step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void step(){
        if(step_idx>=information.length  || information[step_idx] == null){
            timeline.stop();
            return;
        }
        if(information[step_idx].end==true){
            make_all_bar_green();
            timeline.stop();
            return;
        }

        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
        bars[information[step_idx].i].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));

        bars[information[step_idx].j].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));

        if(information[step_idx].move_down==true){
            StackPane stack_move = (StackPane) bar_container.getChildren().get(information[step_idx].move_idx);
            //int starting_x=information[step_idx].move_down_x*information[step_idx].count;
            Information3 ob=information[step_idx];
            int starting_x=(information[step_idx].move_down_x+ ((ob.l1-ob.l)+(ob.mid1-ob.mid))*35);
            double currentLayoutX = stack_move.getLayoutX();

            TranslateTransition down=new TranslateTransition(Duration.millis(300),stack_move);
            down.setToX(starting_x - currentLayoutX);
            down.setToY(150);
            down.play();
        }
        if(information[step_idx].move_up==true){

            int left=information[step_idx].move_up_left;
            int right=information[step_idx].move_up_right;
          /* for(int i=left;i<right;i++){
                for(int j=i+1;j<=right;j++){
                    StackPane stack1 = (StackPane) bar_container.getChildren().get(i);
                    StackPane stack2 = (StackPane) bar_container.getChildren().get(j);

                    /*double h1 = ((Rectangle) stack1.getChildren().get(0)).getHeight();
                    double h2 = ((Rectangle) stack2.getChildren().get(0)).getHeight();
                    double x1 = stack1.getLayoutX();
                    double x2 = stack2.getLayoutX();

                    if(x2 < x1){
                    //if(h2<h1){
                        StackPane nodeA = (StackPane) bar_container.getChildren().get(i);
                        StackPane nodeB = (StackPane) bar_container.getChildren().get(j);
                        //bar_container.getChildren().set(i, nodeB);
                        //bar_container.getChildren().set(j, nodeA);
                        double temp = nodeA.getLayoutX();
                        nodeA.setLayoutX(nodeB.getLayoutX());
                        nodeB.setLayoutX(temp);
                        //Collections.swap(bar_container.getChildren(), i, j);
                        TranslateTransition upA = new TranslateTransition(Duration.millis(300), nodeA);
                        TranslateTransition upB = new TranslateTransition(Duration.millis(300), nodeB);

                        upA.setToY(0);
                        upB.setToY(0);

                        final int i1=i;
                        final int j1=j;
                        upA.setOnFinished(e -> {
                            Collections.swap(bar_container.getChildren(), i1, j1);
                        });

                        upA.play();
                        upB.play();
                    }
                }
            }*/
            bar_container.getChildren().sort(
                    Comparator.comparingDouble(node -> node.getLayoutX() )
            );
            /*for(Node node : bar_container.getChildren()){
                node.setLayoutX(node.getLayoutX() + node.getTranslateX());
                node.setTranslateX(0);
            }*/

            for(int i=information[step_idx].move_up_left;i<=information[step_idx].move_up_right;i++){
                StackPane stack_move = (StackPane) bar_container.getChildren().get(i);
                TranslateTransition up=new TranslateTransition(Duration.millis(300),stack_move);
              /*  up.setToY(-120);
                up.play();*/
                up.setToX(0); // Return to its NEW home LayoutX
                up.setToY(0); // Return to home Y
                up.play();
            }

        }
        step_idx++;

    }

    @FXML
    private void pause_sorting(){
        if(timeline!=null){
            timeline.pause();
        }
    }
    @FXML
    private void resume_sorting(){
        if(timeline!=null && timeline.getStatus()== Animation.Status.PAUSED){
            timeline.play();
        }
    }
    @FXML
    private  void reset_sorting(){
        if(timeline!=null){
            timeline.stop();
            timeline=null;
        }
        bar_container.getChildren().clear();
    }
    @FXML
    private void speed_up(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate<2){
                timeline.setRate(curr_rate+.5);
            }
        }
    }
    @FXML
    private void speed_down(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate>.5){
                timeline.setRate(curr_rate-.5);
            }
        }
    }
    @FXML
    private void next_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step();
            }
        }
    }
    @FXML
    private void previous_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step_prev();
            }
        }
    }
    private void step_prev(){
        /*step_idx--;
        if(step_idx>=information.length  || information[step_idx] == null || step_idx<0){
            timeline.stop();
            return;
        }
        if(information[step_idx].end==true){
            timeline.stop();
            return;
        }
        for(int i=0;i<information[step_idx].i;i++){
            bars[i].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
        for(int i=information[step_idx].i;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
        bars[information[step_idx].i].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));
        bars[information[step_idx].j].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.GOLD),       // light top
                new Stop(1, Color.ORANGE)      // deeper bottom
        ));
        bars[information[step_idx].min_idx].setFill(new LinearGradient(
                0, 0, 0, 1,  // vertical gradient
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),    // lighter red at top
                new Stop(1, Color.DARKRED)    // darker red at bottom
        ));


        if(information[step_idx].swaped==true){

            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].i);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].min_idx);

            // Get the Text nodes from the StackPanes (index 1 because Rect is index 0)
            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            // Swap Heights (using your existing logic)
            double tempHeight = bars[information[step_idx].i].getHeight();
            bars[information[step_idx].i].setHeight(bars[information[step_idx].min_idx].getHeight());
            bars[information[step_idx].min_idx].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);
        }*/
    }
    private void make_all_bar_green(){
        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
    }

    @FXML
    private void initialize() {
       /* bar_container.setAlignment(Pos.BOTTOM_CENTER);
        bar_container.setSpacing(5);*/
        legendRow.getChildren().addAll(
                legendItem("left", "red"),
                legendItem("right", "red"),
                legendItem("sorted", "green")
        );
    }
    @FXML
    private HBox legendRow;
    private HBox legendItem(String name, String colorClass) {

        Region rect = new Region();
        rect.getStyleClass().addAll("legend-rect", colorClass);

        Label label = new Label(name);
        label.getStyleClass().add("legend-text");

        HBox item = new HBox(6, rect, label);
        item.setAlignment(Pos.CENTER_LEFT);

        return item;
    }

}
