package com.example.dsavisualization;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class OpeningSceneController {
    private Scene scene;
    private Stage stage;
    private Parent root;

    @FXML
    Button start_btn;

    public void opening_to_menu(ActionEvent event)throws IOException {
        root= FXMLLoader.load(getClass().getResource("menu_scene.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String css=this.getClass().getResource("menu.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();

    }
}
