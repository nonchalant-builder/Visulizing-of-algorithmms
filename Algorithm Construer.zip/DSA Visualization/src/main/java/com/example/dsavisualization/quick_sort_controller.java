package com.example.dsavisualization;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.Random;

class Information_quick_sort{
    int i;
    int j;
    int pivot;
    boolean swapped=false;
    boolean pivot_swapped=false;
    boolean end=false;
}

public class quick_sort_controller {
    @FXML
    HBox bar_container;
    private Rectangle[] bars;
    private Timeline timeline;
    private int step_idx=0;
    @FXML
    private TextField array_element;
    private int []array;
    private int size;
    Information_quick_sort []information=new Information_quick_sort[1000];
    int info_count;
    ArrayList<Integer>pivots=new ArrayList<>();

    @FXML
    private void set_array_by_user() {
        if(timeline!=null){
            return;
        }
        String element_text = array_element.getText().trim();
        String[] elements = element_text.split("\\s+");
        array_element.clear();

        if (element_text.isEmpty() || !element_text.matches("^[0-9\\s]+$")) {
            return;
        }
        try {
            size = elements.length;
            array = new int[size];
            for (int i = 0; i < size; i++) {
                array[i] = Integer.parseInt(elements[i]);
            }
            set_bars();
        }catch (NumberFormatException e){
            System.out.println("error in input");
        }
    }
    @FXML
    private void set_array_by_random() {
        if(timeline!=null){
            return;
        }
        size = 20;

        array = new int[size];
        Random rand = new Random();

        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(281) + 20;
        }
        set_bars();
    }
    private void set_bars() {
        bar_container.getChildren().clear();
        bars = new Rectangle[size];

        for (int i = 0; i < size; i++) {
            Rectangle bar = new Rectangle();
            bar.setWidth(30);
            bar.setHeight(array[i]);
            bar.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
            bar.setArcWidth(4);
            bar.setArcHeight(4);
            bars[i] = bar;

            // 2. Create the Text label
            Text text = new Text(String.valueOf(array[i]));
            text.setFill(Color.BLACK);
            text.setStyle("-fx-font-size: 14px;-fx-font-weight: bold;");

            // 3. Wrap them in a StackPane
            StackPane stack = new StackPane();
            stack.getChildren().addAll(bar, text);
            stack.setAlignment(Pos.BOTTOM_CENTER);

            bar_container.getChildren().add(stack);
        }
    }
    @FXML
    private void start_sorting(){
        if(timeline!=null){
            return;
        }
        if(array==null || array.length==0){
            return;
        }
        info_count=0;
        set_information();
        step_idx=0;
        timeline=new Timeline(new KeyFrame(Duration.millis(300), e->step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }
    private void set_information(){
        quickSort(0,size);

        information[info_count]=new Information_quick_sort();
        information[info_count++].end=true;
    }
    private void quickSort(int lo,int hi){
        if(lo<hi){
            int idx=partition(lo,hi);
            quickSort(lo,idx);
            quickSort(idx+1,hi);
        }
    }
    private int partition(int lo,int hi){
        int pivot=array[lo];
        int i=lo;
        int j=hi;

        information[info_count]=new Information_quick_sort();
        information[info_count].i=i;
        information[info_count].j=j;
        information[info_count++].pivot=lo;

        while(i<j){
            do{
                i++;

                information[info_count]=new Information_quick_sort();
                information[info_count].i=i;
                information[info_count].j=j;
                information[info_count++].pivot=lo;

            }while(i<size && array[i]<=pivot);

            do{
                j--;

                information[info_count]=new Information_quick_sort();
                information[info_count].i=i;
                information[info_count].j=j;
                information[info_count++].pivot=lo;

            }while(j>=0 && array[j]>pivot);

            if(i<j){
                //swap
                information[info_count]=new Information_quick_sort();
                information[info_count].i=i;
                information[info_count].j=j;
                information[info_count++].pivot=lo;

                information[info_count]=new Information_quick_sort();
                information[info_count].i=i;
                information[info_count].j=j;
                information[info_count].pivot=lo;
                information[info_count++].swapped=true;

                int temp=array[j];
                array[j]=array[i];
                array[i]=temp;
            }
        }
        //swapping pivot
        information[info_count]=new Information_quick_sort();
        information[info_count].i=i;
        information[info_count].j=j;
        information[info_count++].pivot=lo;

        information[info_count]=new Information_quick_sort();
        information[info_count].i=i;
        information[info_count].j=j;
        information[info_count].pivot=lo;
        information[info_count++].pivot_swapped=true;

        int temp=array[lo];
        array[lo]=array[j];
        array[j]=temp;

        return j;
    }

    private void step(){
        if(step_idx>=info_count){
            make_all_bar_green();
            timeline.pause();
            return;
        }
        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),//making normal bar color
                    new Stop(1, Color.SKYBLUE)));
        }
        if (information[step_idx].i >= 0 && information[step_idx].i < bars.length) {

            bars[information[step_idx].i].setFill(new LinearGradient(
                    0, 0, 0, 1,  // vertical gradient
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.SALMON),    // lighter red at top
                    new Stop(1, Color.DARKRED)    // darker red at bottom
            ));
        }
        if (information[step_idx].j >= 0 && information[step_idx].j < bars.length) {

            bars[information[step_idx].j].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.GOLD),       // light top
                    new Stop(1, Color.ORANGE)      // deeper bottom
            ));
        }
        if (information[step_idx].pivot >= 0 && information[step_idx].pivot < bars.length) {
            bars[information[step_idx].pivot].setFill(new LinearGradient(
                    0, 0, 0, 1,  // vertical gradient
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.ORANGE),    // lighter red at top
                    new Stop(1, Color.DARKRED)    // darker red at bottom
            ));
        }
        for(int i=0;i<pivots.size();i++){
            bars[pivots.get(i)].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
        if(information[step_idx].swapped==true){
            if (information[step_idx].i < 0 || information[step_idx].i >= bars.length || information[step_idx].j < 0 || information[step_idx].j >= bars.length) return;
            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].i);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].j);
            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            double tempHeight = bars[information[step_idx].i].getHeight();
            bars[information[step_idx].i].setHeight(bars[information[step_idx].j].getHeight());
            bars[information[step_idx].j].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);
        }
        if(information[step_idx].pivot_swapped==true){
            if (information[step_idx].pivot < 0 || information[step_idx].pivot >= bars.length || information[step_idx].j < 0 || information[step_idx].j >= bars.length) return;

            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].pivot);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].j);

            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            double tempHeight = bars[information[step_idx].pivot].getHeight();
            bars[information[step_idx].pivot].setHeight(bars[information[step_idx].j].getHeight());
            bars[information[step_idx].j].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);

            pivots.add(information[step_idx].j);
            bars[information[step_idx].j].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),       // light top
                    new Stop(1, Color.LIMEGREEN)      // deeper bottom
            ));
        }
        step_idx++;

    }

    private void make_all_bar_green(){
        for (int i = 0; i < bars.length; i++) {
            bars[i].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
    }
    private void step_prev(){
        if(step_idx<0){
            for(int i=0;i<bars.length;i++){
                bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                        new Stop(0, Color.LIGHTSKYBLUE),//making normal bar color
                        new Stop(1, Color.SKYBLUE)));
            }
            step_idx=1;
            return;
        }
        if(step_idx>=info_count || information[step_idx].end){
            step_idx=info_count-2;
        }
        step_idx--;
        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),//making normal bar color
                    new Stop(1, Color.SKYBLUE)));
        }
        if(step_idx<0 || step_idx>=info_count){
            return;
        }
        if (information[step_idx].i >= 0 && information[step_idx].i < bars.length) {

            bars[information[step_idx].i].setFill(new LinearGradient(
                    0, 0, 0, 1,  // vertical gradient
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.SALMON),    // lighter red at top
                    new Stop(1, Color.DARKRED)    // darker red at bottom
            ));
        }
        if (information[step_idx].j >= 0 && information[step_idx].j < bars.length) {

            bars[information[step_idx].j].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.GOLD),       // light top
                    new Stop(1, Color.ORANGE)      // deeper bottom
            ));
        }
        if (information[step_idx].pivot >= 0 && information[step_idx].pivot < bars.length) {
            bars[information[step_idx].pivot].setFill(new LinearGradient(
                    0, 0, 0, 1,  // vertical gradient
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.ORANGE),    // lighter red at top
                    new Stop(1, Color.DARKRED)    // darker red at bottom
            ));
        }
        for(int i=0;i<pivots.size();i++){
            bars[pivots.get(i)].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
        //need to work with pivots
        if((step_idx+1)<info_count) {
            if(information[step_idx+1].pivot_swapped) {
                if (!pivots.isEmpty()) {
                    pivots.removeLast();
                }
            }
        }

        for(int i=0;i<pivots.size();i++){
            bars[pivots.get(i)].setFill(new LinearGradient(
                    0, 0, 0, 1,               // vertical gradient
                    true,                      // proportional
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),  // top: soft yellow-green
                    new Stop(1, Color.LIMEGREEN)          // bottom: deeper green
            ));
        }
        if(information[step_idx].swapped==true){
            if (information[step_idx].i < 0 || information[step_idx].i >= bars.length || information[step_idx].j < 0 || information[step_idx].j >= bars.length) return;
            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].i);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].j);

            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            double tempHeight = bars[information[step_idx].i].getHeight();
            bars[information[step_idx].i].setHeight(bars[information[step_idx].j].getHeight());
            bars[information[step_idx].j].setHeight(tempHeight);

            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);
        }
        if(information[step_idx].pivot_swapped==true){
            if (information[step_idx].pivot < 0 || information[step_idx].pivot >= bars.length || information[step_idx].j < 0 || information[step_idx].j >= bars.length) return;

            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].pivot);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].j);

            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            double tempHeight = bars[information[step_idx].pivot].getHeight();
            bars[information[step_idx].pivot].setHeight(bars[information[step_idx].j].getHeight());
            bars[information[step_idx].j].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);

            if(pivots.getLast()==information[step_idx].pivot){
                pivots.removeLast();
            }
           bars[information[step_idx].j].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),       // light top
                    new Stop(1, Color.LIMEGREEN)      // deeper bottom
            ));
        }

    }

    @FXML
    private void pause_sorting(){
        if(timeline!=null){
            timeline.pause();
        }
    }
    @FXML
    private void resume_sorting(){
        if(timeline!=null && timeline.getStatus()== Animation.Status.PAUSED){
            timeline.play();
        }
    }
    @FXML
    private  void reset_sorting(){
        if(timeline!=null){
            timeline.stop();
            timeline=null;
        }
        bar_container.getChildren().clear();
    }
    @FXML
    private void speed_up(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate<2){
                timeline.setRate(curr_rate+.5);
            }
        }
    }
    @FXML
    private void speed_down(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate>.5){
                timeline.setRate(curr_rate-.5);
            }
        }
    }
    @FXML
    private void next_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step();
            }
        }
    }
    @FXML
    private void previous_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step_prev();
            }
        }
    }

    @FXML
    private VBox code_pane;
    @FXML
    private void initialize() {

        bar_container.setAlignment(Pos.BOTTOM_CENTER);
        bar_container.setSpacing(5);

        String[] code = {
                "void quickSort(int l,int h){",
                "  if(l<hi){",
                "     int p=partition(l,h);",
                "     quickSort(l,p);",
                "     quickSort(p+1,h);",
                "  }",
                "}",
                "int partition(int l,int h){",
                "   int pivot=arr[lo];",
                "   int i=l,j=h;",
                "   while(i<j){",
                "      do{",
                "        i++;",
                "      }while(i<length && ",
                "            arr[i]<=pivot);",
                "      do{",
                "        j--;",
                "      }while(j>=0 && ",
                "            arr[j]>=pivot);",
                "      if(i<j){",
                "         swap(arr[i],arr[j]);",
                "      }",
                "  }",
                "  swap(arr[l],arr[j]);",
                "}"


        };

        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }

                legendRow.getChildren().addAll(
                        legendItem("i", "red"),
                        legendItem("j", "yellow"),
                        legendItem("sorted", "green"),
                        legendItem("pivot", "orange")

                );


    }
    @FXML
    private HBox legendRow;
    private HBox legendItem(String name, String colorClass) {

        Region rect = new Region();
        rect.getStyleClass().addAll("legend-rect", colorClass);

        Label label = new Label(name);
        label.getStyleClass().add("legend-text");

        HBox item = new HBox(6, rect, label);
        item.setAlignment(Pos.CENTER_LEFT);

        return item;
    }
}
