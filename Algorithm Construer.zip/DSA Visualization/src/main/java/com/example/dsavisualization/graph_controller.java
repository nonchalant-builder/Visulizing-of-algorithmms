package com.example.dsavisualization;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.*;

class Information_graph{
    StackPane stack;
    Line line;

    boolean found=false;
    boolean leave=false;
    boolean colorEdge=false;
}

class AdjEdge {
    Vertex vertex=null;   // neighbour
    Line line=null;       // visual edge
    AdjEdge(Vertex v,Line l){
        vertex=v;
        line=l;
    }
}

class Vertex{
    StackPane stack;
    Circle circle;
    Text text;
    String name;
    private double offsetX;
    private double offsetY;


    Vertex(String value,graph_controller controller){
        circle=new Circle(20);
        //circle.setFill(Color.LIGHTSKYBLUE);
        circle.setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.web("#e6f4ff")),
                new Stop(1, Color.web("#bcdcff"))
        ));
        circle.setStroke(Color.web("#6b8fbf"));
        //circle.setStroke(Color.BLACK);
        circle.setStrokeWidth(3);
        text=new Text(value);
        name=value;
        stack=new StackPane(circle,text);
        stack.setLayoutX(50);
        stack.setLayoutY(50);

        stack.setOnMousePressed(e->{
            offsetX=e.getSceneX()-stack.getLayoutX();
            offsetY=e.getSceneY()-stack.getLayoutY();

            if(controller.isEdgeMode()){

            }
        });
        stack.setOnMouseDragged(e->{
            if(controller.isNodeMode()) {
                stack.setLayoutX(e.getSceneX() - offsetX);
                stack.setLayoutY(e.getSceneY() - offsetY);
            }
        });
        stack.setOnMouseReleased(e->{
            if(controller.isNodeMode()) {
                stack.setLayoutX(e.getSceneX() - offsetX);
                stack.setLayoutY(e.getSceneY() - offsetY);
            }
        });
        stack.setOnMouseClicked(e->{
            if(controller.isEdgeMode()) {
                controller.vertexClicked(this);
            }
        });
    }
}

public class graph_controller {
    private boolean nodeMode=false;
    private boolean edgeMode=false;
    private boolean firstSelected=false;
    private Vertex firstVertex=null;
    private Vertex secondVertex=null;
    private Line edge;
    private int vertexCount=0;
    HashMap<Vertex,ArrayList<AdjEdge>> map=new HashMap<>();
    ArrayList<Vertex> vertices=new ArrayList<>();
    ArrayList<Line> lines=new ArrayList<>();
    Information_graph []information=new Information_graph[1000];
    private int info_count;
    Timeline timeline=null;
    private int step_idx;
    @FXML
    private AnchorPane graph_container;
    @FXML
    private TextField insert_text;
    @FXML
    private TextField starting_vertex_text;
    @FXML
    private void insert_btn_clicked(){
        if(timeline!=null){
            return;
        }
        resetModes();
        String txt=insert_text.getText().trim();
        if (txt.isEmpty() || !txt.matches("^[a-zA-Z0-9]+$")) {
            insert_text.clear();
            return;
        }
        insert_text.clear();
        insert(txt);
    }
    private void insert(String value){
        //checking if in this name other vertices are there
        for(int i=0;i<vertices.size();i++){
            if(vertices.get(i).name.equals(value)){
                return;
            }
        }

        Vertex vertex=new Vertex(value,this);
        graph_container.getChildren().add(vertex.stack);
        ArrayList<AdjEdge> adj=new ArrayList<>();
        map.put(vertex,adj);
        vertexCount++;
        vertices.add(vertex);
    }
    @FXML
    private Button node_btn;
    @FXML
    private Button edge_btn;

    private void updateButtonStyles() {
        // Reset both to default
        node_btn.getStyleClass().remove("active-mode");
        edge_btn.getStyleClass().remove("active-mode");

        if (nodeMode) {
            node_btn.getStyleClass().add("active-mode");
        } else if (edgeMode) {
            edge_btn.getStyleClass().add("active-mode");
        }
    }
    @FXML
    private void node_btn_clicked(){
        nodeMode=true;
        edgeMode=false;
        updateButtonStyles();
    }
    @FXML
    private void edge_btn_clicked(){
        edgeMode=true;
        nodeMode=false;
        updateButtonStyles();
    }
    private void resetModes() {
        nodeMode = false;
        edgeMode = false;
        node_btn.getStyleClass().remove("active-mode");
        edge_btn.getStyleClass().remove("active-mode");

        if (nodeMode) {
            node_btn.getStyleClass().add("button");
        } else if (edgeMode) {
            edge_btn.getStyleClass().add("button");
        }

    }
    public boolean isNodeMode(){
        return nodeMode;
    }

    public boolean isEdgeMode() {
        return edgeMode;
    }

    public boolean isFirstSelected() {
        return firstSelected;
    }
    public void setFirstSelected(boolean bool){
        firstSelected=bool;
    }
    public void vertexClicked(Vertex v){
        if(!firstSelected){
            firstSelected=true;
            firstVertex=v;

            edge=new Line();
            edge.setStroke((Color.web("#6b8fbf")));
            edge.setStrokeWidth(2);

            edge.startXProperty().bind(v.stack.layoutXProperty().add(20));
            edge.startYProperty().bind(v.stack.layoutYProperty().add(20));

            edge.endXProperty().bind(edge.startXProperty());
            edge.endYProperty().bind(edge.startYProperty());

            graph_container.getChildren().addFirst(edge);

            graph_container.setOnMouseMoved(e -> {
                edge.endXProperty().unbind();
                edge.endYProperty().unbind();
                edge.setEndX(e.getX());
                edge.setEndY(e.getY());
            });

            return;
        }
        secondVertex=v;
        if(firstVertex == secondVertex){
            cancelEdge();
            return;
        }
        edge.endXProperty().bind(secondVertex.stack.layoutXProperty().add(20));
        edge.endYProperty().bind(secondVertex.stack.layoutYProperty().add(20));

        // Remove mouse move listener
        graph_container.setOnMouseMoved(null);

        map.get(firstVertex).add(new AdjEdge(secondVertex,edge));
        map.get(secondVertex).add(new AdjEdge(firstVertex,edge));

        lines.add(edge);

        firstSelected = false;
        firstVertex = null;
        edge = null;

    }
    private void cancelEdge(){
        graph_container.setOnMouseMoved(null);
        graph_container.getChildren().remove(edge);
        firstSelected = false;
        firstVertex = null;
        edge = null;
    }
    @FXML
    private void dfs_btn_clicked(){
        if(timeline!=null){
            return;
        }
        resetModes();
        dfs_code();
        Vertex startingVertex=null;
        String txt=starting_vertex_text.getText().trim();
        if (txt.isEmpty() || !txt.matches("^[a-zA-Z0-9]+$")) {
            starting_vertex_text.clear();
            return;
        }
        info_count=0;
        for(int i=0;i<vertices.size();i++){
            if(vertices.get(i).name.equals(txt)){
                startingVertex=vertices.get(i);
                break;
            }
        }
        if (startingVertex == null) {
            System.out.println("Error: Starting vertex not found!");
            return;
        }

        HashMap<Vertex, Boolean>visited=new HashMap<>();
        for(int i=0;i<vertices.size();i++){
            visited.put(vertices.get(i),false);
        }

        dfs(startingVertex,map,visited);
        for(int i=0;i<vertices.size();i++){
            if(!visited.get(vertices.get(i))){
                dfs(vertices.get(i),map,visited);
            }
        }
       /* System.out.println("------ graph INFORMATION STATUS ------");
        for (int i = 0; i < info_count; i++) {
            Information_graph info = information[i];
            Text text = (Text) info.stack.getChildren().get(1);
            System.out.printf(
                    "Index: %d | Value: %s | found: %b | leave: %b%n",
                    i,
                    text.getText(),
                    info.found,
                    info.leave
            );
        }
        System.out.println("------------------------------------");*/
        start_timeline();
    }

    private void dfs(Vertex vertex, HashMap<Vertex, ArrayList<AdjEdge>> map, HashMap<Vertex, Boolean> visited) {
        visited.put(vertex, true);

        information[info_count] = new Information_graph();
        information[info_count].stack = vertex.stack;
        information[info_count].found = true;
        info_count++;

        for (int i = 0; i < map.get(vertex).size(); i++) {
            AdjEdge adjEdge = map.get(vertex).get(i);

            if (!visited.get(adjEdge.vertex)) {
                 information[info_count] = new Information_graph();
                 information[info_count].stack=adjEdge.vertex.stack;
                 information[info_count].line = adjEdge.line;
                 information[info_count].colorEdge=true;
                 info_count++;

                dfs(adjEdge.vertex, map, visited);
            }
        }

        information[info_count] = new Information_graph();
        information[info_count].stack = vertex.stack;
        information[info_count].leave = true;
        info_count++;
    }
    private void start_timeline(){
        if(timeline!=null){
            return;
        }
       // graph_container.getChildren().add(currCircle);
        timeline=new Timeline(new KeyFrame(Duration.millis(600), e->step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        step_idx=0;
        timeline.play();
    }
    private void step(){
        if(step_idx >= info_count){
            timeline.pause();
            return;
        }
        if(step_idx<0){
            step_idx=0;
        }
        if(step_idx<info_count && step_idx>=0){
            if(information[step_idx].found){
                if(step_idx==0){
                    highlight_border(information[step_idx].stack,"blackToYellow");
                }
                color_circle(information[step_idx].stack,"blueToOrange");
            }
            if(information[step_idx].colorEdge){
                highlight_edge(information[step_idx].line,"blackToYellow");
                highlight_border(information[step_idx].stack,"blackToYellow");
            }
            if(information[step_idx].leave){
                color_circle(information[step_idx].stack,"orangeToGreen");
            }
            step_idx++;
        }
    }
    private void highlight_border(StackPane stack,String color){
        Circle circle=(Circle)stack.getChildren().get(0);
        StrokeTransition st=new StrokeTransition(Duration.millis(300),circle);
        if(color.equals("blackToYellow")){
            st.setFromValue((Color)circle.getStroke());
            st.setToValue(Color.YELLOW);
        }
        if(color.equals("yellowToBlack")){
            st.setFromValue((Color)circle.getStroke());
            //st.setToValue(Color.BLACK);
            st.setToValue(Color.web("#6b8fbf"));
        }
       // activeAnimations.add(st);
        st.play();
    }
    private void highlight_edge(Line edge,String color){
        if(edge==null){
            return;
        }
        StrokeTransition st=new StrokeTransition(Duration.millis(400),edge);

        if(color.equals("blackToYellow")){
            st.setFromValue((Color)edge.getStroke());
            st.setToValue(Color.YELLOW);
        }
        if(color.equals("yellowToBlack")){
            st.setFromValue((Color)edge.getStroke());
           // st.setToValue(Color.BLACK);
            st.setToValue(Color.web("#6b8fbf"));
        }
       // activeAnimations.add(st);
        st.play();
    }
    private void color_circle(StackPane stack,String color){
        Circle circle=(Circle)stack.getChildren().get(0);
        FillTransition ft=new FillTransition(Duration.millis(250), circle);
        //ft.setFromValue((Color) circle.getFill());
        if(color.equals("blueToOrange")) {
            ft.setFromValue(Color.LIGHTSKYBLUE);
            ft.setToValue(Color.ORANGE);
        }
        else if(color.equals("orangeToGreen")){
            ft.setFromValue(Color.ORANGE);
            ft.setToValue(Color.LIMEGREEN);
        }
        else if(color.equals("greenToOrange")){
            ft.setFromValue(Color.LIMEGREEN);
            ft.setToValue(Color.ORANGE);
        }
        else if(color.equals("orangeToBlue")){
            //ft.setFromValue(Color.ORANGE);
            //ft.setToValue(Color.LIGHTSKYBLUE);
            circle.setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.web("#e6f4ff")),
                    new Stop(1, Color.web("#bcdcff"))
            ));
        }
       // activeAnimations.add(ft);
        ft.play();
    }
    @FXML
    private void bfs_btn_clicked(){
        if(timeline!=null){
            return;
        }
        resetModes();
        bfs_code();
        Vertex startingVertex=null;
        String txt=starting_vertex_text.getText().trim();
        if (txt.isEmpty() || !txt.matches("^[a-zA-Z0-9]+$")) {
            starting_vertex_text.clear();
            return;
        }
        info_count=0;
        for(int i=0;i<vertices.size();i++){
            if(vertices.get(i).name.equals(txt)){
                startingVertex=vertices.get(i);
                break;
            }
        }
        if (startingVertex == null) {
            return;
        }

        HashMap<Vertex, Boolean>visited=new HashMap<>();
        for(int i=0;i<vertices.size();i++){
            visited.put(vertices.get(i),false);
        }

        bfs(startingVertex,map,visited);
        for(int i=0;i<vertices.size();i++){
            if(!visited.get(vertices.get(i))){
                bfs(vertices.get(i),map,visited);
            }
        }
        start_timeline();
    }

   private void bfs(Vertex startNode, HashMap<Vertex, ArrayList<AdjEdge>> map, HashMap<Vertex, Boolean> visited) {
       Queue<Vertex> queue = new LinkedList<>();

       visited.put(startNode, true);
       queue.add(startNode);

       while (!queue.isEmpty()) {
           Vertex current = queue.poll();

           information[info_count] = new Information_graph();
           information[info_count].stack = current.stack;
           information[info_count].found = true;
           info_count++;

           for (AdjEdge adjEdge : map.get(current)) {
               Vertex neighbor = adjEdge.vertex;

               if (!visited.get(neighbor)) {
                   visited.put(neighbor, true);

                   information[info_count] = new Information_graph();
                   information[info_count].stack=adjEdge.vertex.stack;
                   information[info_count].line = adjEdge.line;
                   information[info_count].colorEdge = true;
                   info_count++;

                   queue.add(neighbor);
               }
           }

           information[info_count] = new Information_graph();
           information[info_count].stack = current.stack;
           information[info_count].leave = true;
           info_count++;
       }
   }
    @FXML
    private void stop_btn_clicked(){
        if (timeline!=null) {
            timeline.stop();
            timeline=null;
        }
        resetModes();

        for(int i=0;i<vertices.size();i++){
            color_circle(vertices.get(i).stack,"orangeToBlue");
            highlight_border(vertices.get(i).stack,"yellowToBlack");
        }
        for(int i=0;i<lines.size();i++){
            highlight_edge(lines.get(i),"yellowToBlack");
        }
        //graph_container.getChildren().clear();
        step_idx=0;
        info_count=0;
    }
    @FXML
    private void reset_btn_clicked(){
        if (timeline != null) {
            timeline.stop();
            timeline = null;
        }
        resetModes();

        graph_container.getChildren().clear();

        map.clear();
        vertices.clear();
        lines.clear();

        step_idx = 0;
        info_count = 0;
        vertexCount = 0;

        firstSelected = false;
        firstVertex = null;
        secondVertex = null;
        edge = null;
    }
    @FXML
    private void pause_btn_clicked(){
        if(timeline!=null && timeline.getStatus()== Animation.Status.RUNNING){
            timeline.pause();
        }
    }
    @FXML
    private void resume_btn_clicked(){
        if(timeline!=null && timeline.getStatus()== Animation.Status.PAUSED){
            timeline.play();
        }
    }
    @FXML
    private void speed_up_btn_clicked(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate<3){
                timeline.setRate(curr_rate+.5);
            }
        }
    }
    @FXML
    private void speed_down_btn_clicked(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate>.5){
                timeline.setRate(curr_rate-.5);
            }
        }
    }
    @FXML
    private void next_step_btn_clicked(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                    step();
            }
        }
    }
    @FXML
    private void prev_step_btn_clicked(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                    step_prev();
            }
        }
    }
    private void step_prev(){
        if(step_idx >= info_count){
             step_idx=info_count-1;
        }
        if(step_idx<info_count && step_idx>=0){
            if(information[step_idx].found){
                if(step_idx==0){
                    highlight_border(information[step_idx].stack,"YellowToBlack");
                }
                color_circle(information[step_idx].stack,"orangeToBlue");
            }
            if(information[step_idx].colorEdge){
                highlight_edge(information[step_idx].line,"yellowToBlack");
                highlight_border(information[step_idx].stack,"yellowToBlack");
            }
            if(information[step_idx].leave){
                color_circle(information[step_idx].stack,"greenToOrange");
            }
            step_idx--;
        }
    }
    @FXML
    private void layout_btn_clicked() {
       if(timeline!=null){
           return;
       }
        resetModes();

        double damping = 0.5;
        double kr = 100000;
        double ks = 0.05;
        double L = 250;
        int iterations = 300;

        HashMap<Vertex, Double> dispX = new HashMap<>();
        HashMap<Vertex, Double> dispY = new HashMap<>();

        for (int i = 0; i < iterations; i++) {
            for (Vertex v : vertices) {
                dispX.put(v, 0.0);
                dispY.put(v, 0.0);
            }

            for (Vertex v1 : vertices) {
                for (Vertex v2 : vertices) {
                    if (v1 == v2) continue;
                    double dx = v1.stack.getLayoutX() - v2.stack.getLayoutX();
                    double dy = v1.stack.getLayoutY() - v2.stack.getLayoutY();
                    double d = Math.sqrt(dx * dx + dy * dy) + 0.1;

                    double force = kr / (d * d);
                    dispX.put(v1, dispX.get(v1) + (dx / d) * force);
                    dispY.put(v1, dispY.get(v1) + (dy / d) * force);
                }
            }

            for (Vertex v1 : map.keySet()) {
                for (AdjEdge edge : map.get(v1)) {
                    Vertex v2 = edge.vertex;
                    double dx = v1.stack.getLayoutX() - v2.stack.getLayoutX();
                    double dy = v1.stack.getLayoutY() - v2.stack.getLayoutY();
                    double d = Math.sqrt(dx * dx + dy * dy) + 0.1;

                    double force = ks * (d - L);
                    dispX.put(v1, dispX.get(v1) - (dx / d) * force);
                    dispY.put(v1, dispY.get(v1) - (dy / d) * force);
                }
            }
            double centerX = graph_container.getWidth() / 2;
            double centerY = graph_container.getHeight() / 2;
            double gravityStrength = 0.05;

            for (Vertex v : vertices) {
                double dx = centerX - v.stack.getLayoutX();
                double dy = centerY - v.stack.getLayoutY();

                dispX.put(v, dispX.get(v) + dx * gravityStrength);
                dispY.put(v, dispY.get(v) + dy * gravityStrength);
            }

            double temp = 1.0 - ((double) i / iterations);
            for (Vertex v : vertices) {
                v.stack.setLayoutX(v.stack.getLayoutX() + dispX.get(v) * damping * temp);
                v.stack.setLayoutY(v.stack.getLayoutY() + dispY.get(v) * damping * temp);
            }
        }
    }
    private void createEdge(Vertex v1, Vertex v2) {
        if (v1 == v2 || areAlreadyConnected(v1, v2)) return;

        Line newEdge = new Line();
        newEdge.setStroke((Color.web("#6b8fbf")));
        newEdge.setStrokeWidth(2);

        newEdge.startXProperty().bind(v1.stack.layoutXProperty().add(20));
        newEdge.startYProperty().bind(v1.stack.layoutYProperty().add(20));
        newEdge.endXProperty().bind(v2.stack.layoutXProperty().add(20));
        newEdge.endYProperty().bind(v2.stack.layoutYProperty().add(20));

        graph_container.getChildren().addFirst(newEdge);
        map.get(v1).add(new AdjEdge(v2, newEdge));
        map.get(v2).add(new AdjEdge(v1, newEdge));
        lines.add(newEdge);
    }

    private boolean areAlreadyConnected(Vertex v1, Vertex v2) {
        for (AdjEdge edge : map.get(v1)) {
            if (edge.vertex == v2) return true;
        }
        return false;
    }
    @FXML
    private void random_btn_clicked() {
        if (timeline != null) return;
        reset_btn_clicked();
        resetModes();

        java.util.Random random = new java.util.Random();
        int nodeCount = 12;

        double centerX = 600;
        double centerY = 275;
        double radius = 220;

        for (int i = 0; i < nodeCount; i++) {
            // Create the vertex
            char ch = (char) ('A' + i);
            String value = String.valueOf(ch);
            Vertex v = new Vertex(value, this);

            double angle = 2 * Math.PI * i / nodeCount;
            v.stack.setLayoutX(centerX + radius * Math.cos(angle));
            v.stack.setLayoutY(centerY + radius * Math.sin(angle));

            graph_container.getChildren().add(v.stack);
            vertices.add(v);
            map.put(v, new ArrayList<>());
        }

        int maxEdges = 14;
        int edgesCreated = 0;

        while (edgesCreated < maxEdges) {
            Vertex v1 = vertices.get(random.nextInt(vertices.size()));
            Vertex v2 = vertices.get(random.nextInt(vertices.size()));

            if (v1 != v2 && !areAlreadyConnected(v1, v2)) {
                createEdge(v1, v2);
                edgesCreated++;
            }
        }

        layout_btn_clicked();
    }
    @FXML
    private VBox code_pane;

    @FXML
    private void initialize() {
        bfs_code();
        legendRow.getChildren().addAll(
                legendItem("Comparing", "compare"),
                legendItem("Current", "current"),
                legendItem("Sorted", "sorted"),
                legendItem("Pivot", "pivot")
        );

    }
    @FXML
    private HBox legendRow;
    private HBox legendItem(String name, String colorClass) {

        Region rect = new Region();
        rect.getStyleClass().addAll("legend-rect", colorClass);

        Label label = new Label(name);
        label.getStyleClass().add("legend-text");

        HBox item = new HBox(6, rect, label);
        item.setAlignment(Pos.CENTER_LEFT);

        return item;
    }
    private void bfs_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "void BFS(int startingNode) {",
                "   vector<int> visited(n, 0);",
                "   queue<int> q;",
                "   ",
                "   visited[startingNode] = 1;",
                "   q.push(startingNode);",
                "   ",
                "   while (!q.empty()) {",
                "       int x = q.front();",
                "       q.pop();",
                "       ans.push_back(x);",
                "       ",
                "       for (int i = 0; i < adj[x].size(); i++) {",
                "           int neighbor = adj[x][i];",
                "           ",
                "           if (visited[neighbor] == 0) {",
                "               visited[neighbor] = 1;",
                "               q.push(neighbor);",
                "           }",
                "       }",
                "   }",
                "}"
        };

        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }
    }
    private void dfs_code(){
        code_pane.getChildren().clear();
        String[] code = {
                "",
                "void dfs(int node, vector<int> ",
                "        adj[], int visited[],",
                "        vector<int> &ans) {",
                "   visited[node] = 1;",
                "   ans.push_back(node);",
                "   ",
                "   for (int i = 0; i < ",
                "        adj[node].size();i++){",
                "       int neighbor=adj[node][i];",
                "       ",
                "       if (visited[neighbor]==0){",
                "             dfs(neighbor,adj,",
                "                visited,ans);",
                "       }",
                "   }",
                "}"
        };

        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }

    }
    @FXML
    private void home_btn_clicked(ActionEvent event)throws IOException {
        reset_btn_clicked();
        Parent root= FXMLLoader.load(getClass().getResource("menu_scene.fxml"));
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene=new Scene(root);
        String css=this.getClass().getResource("menu.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
}
