package com.example.dsavisualization;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class sortingAlgorithm_controller {
    @FXML
    private AnchorPane sorting_algorithm_page;
    @FXML
    public void initialize(){
        load_another_page("selection_sort.fxml");
    }
    private void load_another_page(String fxml_file){
        try{
            Parent page= FXMLLoader.load(getClass().getResource(fxml_file));
            sorting_algorithm_page.getChildren().setAll(page);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    private void load_bubble_sort(){
        try{
            Parent page= FXMLLoader.load(getClass().getResource("bubble_sort.fxml"));
            sorting_algorithm_page.getChildren().setAll(page);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    private void load_selection_sort(){
        try{
            Parent page= FXMLLoader.load(getClass().getResource("selection_sort.fxml"));
            sorting_algorithm_page.getChildren().setAll(page);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    private void load_insertion_sort(){
        try{
            Parent page= FXMLLoader.load(getClass().getResource("insertion_sort.fxml"));
            sorting_algorithm_page.getChildren().setAll(page);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    private void load_merge_sort(){
        try{
            Parent page= FXMLLoader.load(getClass().getResource("merge.fxml"));
            sorting_algorithm_page.getChildren().setAll(page);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    private void load_quick_sort(){
        try{
            Parent page= FXMLLoader.load(getClass().getResource("quick.fxml"));
            sorting_algorithm_page.getChildren().setAll(page);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    private void home_btn_clicked(ActionEvent event)throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("menu_scene.fxml"));
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene=new Scene(root);
        String css=this.getClass().getResource("menu.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
}
