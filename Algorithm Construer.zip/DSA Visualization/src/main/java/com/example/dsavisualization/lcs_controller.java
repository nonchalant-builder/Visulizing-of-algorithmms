package com.example.dsavisualization;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

class Information_lcs{
    int i;//i and j is for set value
    int j;
    int compare_to_i;//compare for comparing
    int compare_to_j;
    int compare_from_i;
    int compare_from_j;
    int value;//when need to insert value
    boolean compare=false;
    boolean setValue=false;
    boolean backTrack=false;
    //boolean ansChar=false;
    boolean red=false;//while backtracking the footstep

}


public class lcs_controller {
    @FXML
    Button start_btn;
    @FXML
    Button set_btn;
    @FXML
    private TextField s_text;
    @FXML
    private TextField t_text;
    @FXML
    private GridPane grid;
    @FXML
    private AnchorPane lcs_container;
    Timeline timeline;

    private String s;
    private String t;
    private int[][] dp;
    private Label[][] labels;
    Information_lcs[] information = new Information_lcs[10000];
    int info_count = 0;
    int step_idx;
    int cellSize = 60;

    @FXML
    private void set_btn_clicked() {
        if(timeline!=null){
            return;
        }

        s = s_text.getText().trim();
        t = t_text.getText().trim();
        s_text.clear();
        t_text.clear();
        if(s.length()>=10 || t.length()>=10){
            return;
        }
        if(s.length()>5 || t.length()>5){
            double x=.18*Math.max(s.length(),t.length());
            x=(double) cellSize/x;
            cellSize=(int)x;
        }
        set_table();
        start_btn.setDisable(false);
    }

    private void set_table() {
        grid.getChildren().clear();
        grid.getColumnConstraints().clear();
        grid.getRowConstraints().clear();

        // We add 2 extra tracks for the Index and the Character
        int totalRows = s.length() + 1 + 2;
        int totalCols = t.length() + 1 + 2;

        dp = new int[s.length() + 1][t.length() + 1];
        labels = new Label[s.length() + 1][t.length() + 1];

        for (int j = 0; j < totalCols; j++) grid.getColumnConstraints().add(new ColumnConstraints(cellSize));
        for (int i = 0; i < totalRows; i++) grid.getRowConstraints().add(new RowConstraints(cellSize));

        for (int i = 0; i < totalRows; i++) {
            for (int j = 0; j < totalCols; j++) {
                Label cell = new Label();
                cell.setPrefSize(cellSize, cellSize);
                cell.setAlignment(Pos.CENTER);

                if (i < 2 || j < 2) {
                    cell.setStyle("-fx-border-color: transparent;");
                    setupHeaderContent(cell, i, j);
                }
                else {
                    cell.setStyle("-fx-background-color: transparent; -fx-border-color: white; -fx-text-fill: white; -fx-font-weight: bold;");// cell.setText("0"); // Uncomment this if you want to see zeros initially
                    labels[i - 2][j - 2] = cell;
                }

                grid.add(cell, j, i);
            }
        }

        Platform.runLater(() -> {
            grid.setLayoutX((lcs_container.getWidth() - totalCols * cellSize) / 2);
            grid.setLayoutY((lcs_container.getHeight() - totalRows * cellSize) / 2);
        });
    }

    private void setupHeaderContent(Label cell, int row, int col) {
        if (row == 0 && col >= 2) {
            if (col > 2) cell.setText(String.valueOf(t.charAt(col - 3)));
            cell.setStyle("-fx-text-fill: blue; -fx-font-weight: bold;");
        } else if (row == 1 && col >= 2) {
            cell.setText(String.valueOf(col - 2));
            cell.setStyle("-fx-text-fill: gray;");
        }

        else if (col == 0 && row >= 2) {
            if (row > 2) cell.setText(String.valueOf(s.charAt(row - 3)));
            cell.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
        } else if (col == 1 && row >= 2) {
            cell.setText(String.valueOf(row - 2));
            cell.setStyle("-fx-text-fill: gray;");
        }
    }

    @FXML
    private void start_btn_clicked() {
        if(timeline!=null){
            return;
        }

        info_count = 0;
        lcs();
        start_timeline();
    }

    private void start_timeline() {
        if (timeline != null) {
            return;
        }
        step_idx = 0;
        timeline = new Timeline(new KeyFrame(Duration.millis(300), e -> step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    @FXML
    private void pause_btn_clicked(){
        if(timeline!=null && timeline.getStatus()== Animation.Status.RUNNING){
            timeline.pause();
        }
    }

    @FXML
    private void resume_btn_clicked() {
        if (timeline != null && timeline.getStatus() == Animation.Status.PAUSED) {
            timeline.play();
        }
    }

    @FXML
    private void reset_btn_clicked() {
        if (timeline != null) {
            timeline.stop();
            timeline = null;
        }
        grid.getChildren().clear();
        grid.getColumnConstraints().clear();
        grid.getRowConstraints().clear();
        timeline=null;
        cellSize=60;
        info_count=0;
        step_idx=0;
        start_btn.setDisable(true);
        s=null;
        t=null;
    }

    @FXML
    private void speed_up_btn_clicked() {
        if (timeline != null) {
            double curr_rate = timeline.getCurrentRate();
            if (curr_rate < 2) {
                timeline.setRate(curr_rate + .5);
            }
        }
    }

    @FXML
    private void speed_down_btn_clicked() {
        if (timeline != null) {
            double curr_rate = timeline.getCurrentRate();
            if (curr_rate > .5) {
                timeline.setRate(curr_rate - .5);
            }
        }
    }

    @FXML
    private void next_step_btn_clicked() {
        if (timeline != null) {
            if (timeline.getStatus() == Animation.Status.PAUSED) {
                step();
            }
        }
    }

    @FXML
    private void prev_step_btn_clicked() {
        if (timeline != null) {
            if (timeline.getStatus() == Animation.Status.PAUSED) {
                step_prev();
            }
        }
    }

    @FXML
    private void home_btn_clicked(ActionEvent event) throws IOException {
        reset_btn_clicked();
        Parent root = FXMLLoader.load(getClass().getResource("menu_scene.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        String css = this.getClass().getResource("menu.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

   private void lcs() {
       for (int i = 0; i <= s.length(); i++) {
           dp[i][0] = 0;
           information[info_count] = new Information_lcs();
           information[info_count].i = i;
           information[info_count].j = 0;
           information[info_count].setValue = true;
           information[info_count++].value = 0;
       }
       for (int j = 0; j <= t.length(); j++) {
           dp[0][j] = 0;
           information[info_count] = new Information_lcs();
           information[info_count].i = 0;
           information[info_count].j = j;
           information[info_count].setValue = true;
           information[info_count++].value = 0;
       }

       for (int i = 1; i <= s.length(); i++) {
           for (int j = 1; j <= t.length(); j++) {

               information[info_count] = new Information_lcs();
               information[info_count].i = i;
               information[info_count].j = j;
               info_count++;

               if (s.charAt(i - 1) == t.charAt(j - 1)) {
                   dp[i][j] = 1 + dp[i - 1][j - 1];

                   information[info_count] = new Information_lcs();
                   information[info_count].compare = true;
                   information[info_count].compare_from_i = i;
                   information[info_count].compare_from_j = j;
                   information[info_count].compare_to_i = i - 1;
                   information[info_count++].compare_to_j = j - 1;

                   information[info_count] = new Information_lcs();
                   information[info_count].setValue = true;
                   information[info_count].i = i;
                   information[info_count].j = j;
                   information[info_count++].value = dp[i][j];

               } else {
                   int left = dp[i][j - 1];
                   int up = dp[i - 1][j];
                   dp[i][j] = Math.max(left, up);

                   information[info_count] = new Information_lcs();
                   information[info_count].compare = true;
                   information[info_count].compare_from_i = i;
                   information[info_count].compare_from_j = j;
                   information[info_count].compare_to_i = i - 1;
                   information[info_count++].compare_to_j = j;

                   information[info_count] = new Information_lcs();
                   information[info_count].compare = true;
                   information[info_count].compare_from_i = i;
                   information[info_count].compare_from_j = j;
                   information[info_count].compare_to_i = i;
                   information[info_count++].compare_to_j = j - 1;

                   information[info_count] = new Information_lcs();
                   information[info_count].setValue = true;
                   information[info_count].i = i;
                   information[info_count].j = j;
                   information[info_count++].value = dp[i][j];
               }
           }
       }
       //ba
       int i = s.length();
       int j = t.length();

       while (i > 0 && j > 0) {
           information[info_count] = new Information_lcs();
           information[info_count].backTrack = true;
           information[info_count].i = i;
           information[info_count].j = j;
           info_count++;

           if (s.charAt(i - 1) == t.charAt(j - 1)) {
               information[info_count] = new Information_lcs();
               information[info_count].backTrack = true;
               information[info_count].compare = true;
               information[info_count].compare_from_i = i;
               information[info_count].compare_from_j = j;
               information[info_count].compare_to_i = i - 1;
               information[info_count++].compare_to_j = j - 1;

               information[info_count] = new Information_lcs();
               information[info_count].backTrack = true;
               information[info_count].setValue = true;
               information[info_count].i = i;
               information[info_count++].j = j;

               i--;
               j--;
           } else if (dp[i - 1][j] == dp[i][j]) {
               information[info_count] = new Information_lcs();
               information[info_count].backTrack = true;
               information[info_count].compare = true;
               information[info_count].compare_from_i = i;
               information[info_count].compare_from_j = j;
               information[info_count].compare_to_i = i - 1;
               information[info_count++].compare_to_j = j;

               information[info_count] = new Information_lcs();
               information[info_count].backTrack = true;
               information[info_count].red = true;
               information[info_count].compare_from_i = i;
               information[info_count].compare_from_j = j;
               information[info_count].compare_to_i = i - 1;
               information[info_count++].compare_to_j = j;

               i--;
           } else {
               information[info_count] = new Information_lcs();
               information[info_count].backTrack = true;
               information[info_count].compare = true;
               information[info_count].compare_from_i = i;
               information[info_count].compare_from_j = j;
               information[info_count].compare_to_i = i;
               information[info_count++].compare_to_j = j - 1;

               information[info_count] = new Information_lcs();
               information[info_count].backTrack = true;
               information[info_count].red = true;
               information[info_count].compare_from_i = i;
               information[info_count].compare_from_j = j;
               information[info_count].compare_to_i = i;
               information[info_count++].compare_to_j = j - 1;

               j--;
           }
       }
   }
    private void step() {
        if (step_idx >= info_count) {
            timeline.stop();
            return;
        }

        Information_lcs info = information[step_idx];

        clearTemporaryStyles();
        resetHeaderStyles();

        if (!info.backTrack) {
            if (!info.compare && !info.setValue) {
                glowHeaders(info.i, info.j);
                labels[info.i][info.j].setStyle("-fx-background-color: lightblue; -fx-border-color: white;");
            } else if (info.compare) {
                labels[info.compare_from_i][info.compare_from_j].setStyle("-fx-background-color: lightblue; -fx-border-color: white;");
                labels[info.compare_to_i][info.compare_to_j].setStyle("-fx-background-color: yellow; -fx-border-color: white; -fx-text-fill: black;");
            } else if (info.setValue) {
                labels[info.i][info.j].setText(String.valueOf(info.value));
                labels[info.i][info.j].setStyle("-fx-background-color: lightblue; -fx-border-color: white;");
            }
        } else {
            if (!info.compare && !info.setValue && !info.red) {
                glowHeaders(info.i, info.j);
                labels[info.i][info.j].setStyle("-fx-background-color: red; -fx-border-color: white;");
            } else if (info.compare) {
                labels[info.compare_from_i][info.compare_from_j].setStyle("-fx-background-color: red; -fx-border-color: white;");
                labels[info.compare_to_i][info.compare_to_j].setStyle("-fx-background-color: red; -fx-border-color: white;");
            } else if (info.setValue) {
                labels[info.i][info.j].setStyle("-fx-background-color: green; -fx-border-color: white; -fx-font-weight: bold;");
            } else if (info.red) {
                labels[info.compare_from_i][info.compare_from_j].setStyle("-fx-background-color: red; -fx-border-color: white;");
            }
        }
        step_idx++;
    }
    private void step_prev() {
        if (step_idx <= 0) return;

        step_idx--;
        Information_lcs info = information[step_idx];

        if (info.setValue && !info.backTrack) {
            labels[info.i][info.j].setText("");
        }

        if (info.setValue && info.backTrack) {
            labels[info.i][info.j].setStyle("-fx-background-color: transparent; -fx-border-color: white; -fx-text-fill: white; -fx-font-weight: bold;");
        }

        clearTemporaryStyles();
        resetHeaderStyles();

        if (step_idx > 0) {
            int currentIdx = step_idx;
            step_idx--;
            step();
            step_idx = currentIdx;
        }
    }
    private void clearTemporaryStyles() {
        for (int i = 0; i <= s.length(); i++) {
            for (int j = 0; j <= t.length(); j++) {
                if (labels[i][j] != null) {
                    String style = labels[i][j].getStyle();
                    if (!style.contains("green")) {
                        labels[i][j].setStyle("-fx-background-color: transparent; -fx-border-color: white; -fx-text-fill: white; -fx-font-weight: bold;");
                    }
                }
            }
        }
    }

    private void glowHeaders(int i, int j) {
        if (i <= 0 || j <= 0) return;
        for (Node node : grid.getChildren()) {
            Integer r = GridPane.getRowIndex(node);
            Integer c = GridPane.getColumnIndex(node);

            if (node instanceof Label) {
                Label lbl = (Label) node;
                if (c != null && c == 0 && r != null && r == i + 2) {
                    lbl.setStyle("-fx-text-fill: yellow; -fx-font-weight: bold; -fx-font-size: 20;");
                }
                if (r != null && r == 0 && c != null && c == j + 2) {
                    lbl.setStyle("-fx-text-fill: yellow; -fx-font-weight: bold; -fx-font-size: 20;");
                }
            }
        }
    }

    private void resetHeaderStyles() {
        for (Node node : grid.getChildren()) {
            Integer r = GridPane.getRowIndex(node);
            Integer c = GridPane.getColumnIndex(node);

            if (node instanceof Label) {
                Label lbl = (Label) node;
                // Reset String S column (Col 0) to Red
                if (c != null && c == 0 && r != null && r >= 2) {
                    lbl.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                }
                // Reset String T row (Row 0) to Blue
                if (r != null && r == 0 && c != null && c >= 2) {
                    lbl.setStyle("-fx-text-fill: blue; -fx-font-weight: bold;");
                }
            }
        }
    }
    @FXML
    private VBox code_pane;
    @FXML
    private void initialize(){
        start_btn.setDisable(true);
        lcs_code();
    }
    private void lcs_code(){
        String[] code = {
                "int n=s.length();",
                "int m=t.length();",
                "",
                "int dp[n+1][m+1]={0};",
                "",
                "for(int i=0;i<=n;i++){",
                "   dp[i][0]=0;",
                "}",
                "",
                "for(int j=0;j<=m;j++){",
                "   dp[0][j]=0;",
                "}",
                "",
                "for(int i=1;i<=n;i++){",
                "   for(int j=1;j<=m;j++){",
                "      if(s[i-1]==t[j-1]){",
                "         dp[i][j]=1+dp[i-1][j-1];",
                "      }",
                "      else{",
                "         int left=dp[i][j-1];",
                "         int up=dp[i-1][j];",
                "         dp[i][j]=max(left,up);",
                "      }",
                "   }",
                "}",
                "",
                "// backtracking",
                "int i=n;",
                "int j=m;",
                "string lcs=\"\";",
                "",
                "while(i>0 && j>0){",
                "   if(s[i-1]==t[j-1]){",
                "      lcs+=s[i-1];",
                "      i--;",
                "      j--;",
                "   }",
                "   else if(dp[i-1][j]>dp[i][j-1]){",
                "      i--;",
                "   }",
                "   else{",
                "      j--;",
                "   }",
                "}",
                "",
                "reverse(lcs.begin(),lcs.end());",
                "return lcs;"
        };

        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }
    }
}

