package com.example.dsavisualization;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class AboutController {

  

    @FXML private Label Name;

    /*@FXML
    private void onBackClicked() {
        try {
            
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/algoviz/algoviz/menu_scene.fxml")
            );

            Scene menuScene = new Scene(loader.load(), 1250, 750);
            Stage stage = (Stage) Name.getScene().getWindow();

            stage.setScene(menuScene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
    @FXML
    private void onBackClicked(ActionEvent event)throws IOException {
        //SceneManager.switchTo("openingScence");
        home_btn_clicked(event);
    }//change by ahsan
    @FXML
    private void home_btn_clicked(ActionEvent event)throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("menu_scene.fxml"));
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene=new Scene(root);
        String css=this.getClass().getResource("menu.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
}