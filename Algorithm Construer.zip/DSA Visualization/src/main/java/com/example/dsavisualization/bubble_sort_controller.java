package com.example.dsavisualization;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.Random;
class Information1{
    int i;
    int j;
    boolean swaped=false;
    boolean end=false;
}

public class bubble_sort_controller {
    @FXML
    HBox bar_container;
    @FXML
    VBox code_pane;
    private Rectangle[] bars;
    private Timeline timeline;
    private int step_idx=0;
    @FXML
    private TextField array_element;
    private int []array;
    private int size;

    private int i,j;
    private int min_idx;
    private Information1[] information=new Information1[1000];

    @FXML
    private void set_array_by_user() {
        if(timeline!=null){
            return;
        }
        String element_text = array_element.getText().trim();
        String[] elements = element_text.split("\\s+");
        array_element.clear();

        if (element_text.isEmpty() || !element_text.matches("^[0-9\\s]+$")) {
            return;
        }
        try {
            size = elements.length;
            array = new int[size];
            for (int i = 0; i < size; i++) {
                array[i] = Integer.parseInt(elements[i]);
            }
            set_bars();
        }catch (NumberFormatException e){
            System.out.println("error in input");
        }
    }

    @FXML
    private void set_array_by_random() {
        if(timeline!=null){
            return;
        }
        size = 20;

        array = new int[size];
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(281) + 20;
        }
        set_bars();
    }

    private void set_information(){
        int k=0;
        for(i=0;i<array.length-1;i++){
            for(j=0;j<array.length-1;j++){
                information[k]=new Information1();
                information[k].i=i;
                information[k].j=j;

                if(array[j+1]<array[j]){
                    int temp=array[j];
                    array[j]=array[j+1];
                    array[j+1]=temp;
                    information[k].swaped=true;

                }
                k++;
            }
        }
        information[k]=new Information1();
        information[k].end=true;
    }

    private void set_bars() {
        bar_container.getChildren().clear();
        bars = new Rectangle[size];

        for (int i = 0; i < size; i++) {
            // 1. Create the Rectangle
            Rectangle bar = new Rectangle();
            bar.setWidth(30);
            bar.setHeight(array[i]);
            bar.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
            bar.setArcWidth(4);
            bar.setArcHeight(4);
            bars[i] = bar;

            // 2. Create the Text label
            Text text = new Text(String.valueOf(array[i]));
            text.setFill(Color.BLACK);
            text.setStyle("-fx-font-size: 14px;-fx-font-weight: bold;");

            // 3. Wrap them in a StackPane
            StackPane stack = new StackPane();
            stack.getChildren().addAll(bar, text);
            stack.setAlignment(Pos.BOTTOM_CENTER);

            bar_container.getChildren().add(stack);
        }
    }

    @FXML
    private void start_sorting(){
        if(timeline!=null){
            return;
        }
        if(array==null || array.length==0){
            return;
        }
        set_information();
        step_idx=0;
        timeline=new Timeline(new KeyFrame(Duration.millis(300),e->step()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void step(){
        if(step_idx>=information.length  || information[step_idx] == null){
            timeline.stop();
            return;
        }
        if(information[step_idx].end==true){
            make_all_bar_green();
            timeline.stop();
            return;
        }

        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
        for(int i=0;i<information[step_idx].i;i++){
            bars[bars.length-i-1].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),
                    new Stop(1, Color.LIMEGREEN)
            ));
        }
        bars[information[step_idx].j].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),
                new Stop(1, Color.DARKRED)
        ));
        bars[information[step_idx].i].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.GOLD),
                new Stop(1, Color.ORANGE)
        ));
        bars[information[step_idx].j+1].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),
                new Stop(1, Color.DARKRED)
        ));

        if(information[step_idx].swaped==true){

            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].j);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].j+1);

            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            double tempHeight = bars[information[step_idx].j].getHeight();
            bars[information[step_idx].j].setHeight(bars[information[step_idx].j+1].getHeight());
            bars[information[step_idx].j+1].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);
        }
        step_idx++;

    }

    @FXML
    private void pause_sorting(){
        if(timeline!=null){
            timeline.pause();
        }
    }
    @FXML
    private void resume_sorting(){
        if(timeline!=null && timeline.getStatus()== Animation.Status.PAUSED){
            timeline.play();
        }
    }
    @FXML
    private  void reset_sorting(){
        if(timeline!=null){
            timeline.stop();
            timeline=null;
        }
        bar_container.getChildren().clear();
    }
    @FXML
    private void speed_up(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate<2){
                timeline.setRate(curr_rate+.5);
            }
        }
    }
    @FXML
    private void speed_down(){
        if(timeline!=null){
            double curr_rate=timeline.getCurrentRate();
            if(curr_rate>.5){
                timeline.setRate(curr_rate-.5);
            }
        }
    }
    @FXML
    private void next_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step();
            }
        }
    }
    @FXML
    private void previous_step(){
        if(timeline!=null){
            if(timeline.getStatus()==Animation.Status.PAUSED){
                step_prev();
            }
        }
    }
    private void step_prev(){
        step_idx--;
        if(step_idx>=information.length  || information[step_idx] == null || step_idx<0){
            timeline.stop();
            return;
        }
        if(information[step_idx].end==true){
            timeline.stop();
            return;
        }
        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTSKYBLUE),
                    new Stop(1, Color.SKYBLUE)));
        }
        for(int i=0;i<information[step_idx].i;i++){
            bars[bars.length-i-1].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),
                    new Stop(1, Color.LIMEGREEN)
            ));
        }
        bars[information[step_idx].j].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),
                new Stop(1, Color.DARKRED)
        ));
        bars[information[step_idx].i].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.GOLD),
                new Stop(1, Color.ORANGE)
        ));
        bars[information[step_idx].j+1].setFill(new LinearGradient(
                0, 0, 0, 1,
                true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.SALMON),
                new Stop(1, Color.DARKRED)
        ));


        if(information[step_idx].swaped==true){

            StackPane stackI = (StackPane) bar_container.getChildren().get(information[step_idx].j);
            StackPane stackMin = (StackPane) bar_container.getChildren().get(information[step_idx].j+1);

            Text textI = (Text) stackI.getChildren().get(1);
            Text textMin = (Text) stackMin.getChildren().get(1);

            double tempHeight = bars[information[step_idx].j].getHeight();
            bars[information[step_idx].j].setHeight(bars[information[step_idx].j+1].getHeight());
            bars[information[step_idx].j+1].setHeight(tempHeight);

            // Swap the Text values
            String tempText = textI.getText();
            textI.setText(textMin.getText());
            textMin.setText(tempText);
        }
    }
    private void make_all_bar_green(){
        for(int i=0;i<bars.length;i++){
            bars[i].setFill(new LinearGradient(
                    0, 0, 0, 1,
                    true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTYELLOW),
                    new Stop(1, Color.LIMEGREEN)
            ));
        }
    }

    @FXML
    private void initialize() {

        bar_container.setAlignment(Pos.BOTTOM_CENTER);
        bar_container.setSpacing(5);

        String[] code = {
                " ",
                " ",
                " ",
                "int length=array.size();",
                " ",
                "for(int i=0;i<length;i++){",
                "   for(int j=0;j<length-i-1;j++){",
                "       if(array[j+1] < array[j]){",
                "           int temp = array[j];",
                "           array[j] = array[j+1];",
                "           array[j+1] = temp;",
                "       }",
                "   }",
                "}"
        };

        for(String line : code){
            Label label = new Label(line);
            label.getStyleClass().add("code-line");
            code_pane.getChildren().add(label);
        }

        legendRow.getChildren().addAll(
                legendItem("j", "red"),
                legendItem("j+1", "red"),
                legendItem("i", "yellow"),
                legendItem("sorted", "green")
        );

    }
    @FXML
    private HBox legendRow;
    private HBox legendItem(String name, String colorClass) {

        Region rect = new Region();
        rect.getStyleClass().addAll("legend-rect", colorClass);

        Label label = new Label(name);
        label.getStyleClass().add("legend-text");

        HBox item = new HBox(6, rect, label);
        item.setAlignment(Pos.CENTER_LEFT);

        return item;
    }

}
